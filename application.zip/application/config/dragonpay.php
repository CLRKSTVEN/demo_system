<?php
defined('BASEPATH') or exit('No direct script access allowed');

$config['dragonpay_merchantid'] = '';
$config['dragonpay_password']   = '';
$config['dragonpay_url']        = '';
