                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                School Records Management System | Powered by <a href="https://softtechservices.net" target="_blank">SoftTech Solutions</a> | Registered at the Intellectual Property Office of the Philippines with Cert No. N-2020-00235
                            </div>
                        </div>
                    </div>
                </footer>