<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-11-17 10:37:53 --> Config Class Initialized
INFO - 2025-11-17 10:37:53 --> Hooks Class Initialized
DEBUG - 2025-11-17 10:37:53 --> UTF-8 Support Enabled
INFO - 2025-11-17 10:37:53 --> Utf8 Class Initialized
INFO - 2025-11-17 10:37:53 --> URI Class Initialized
DEBUG - 2025-11-17 10:37:53 --> No URI present. Default controller set.
INFO - 2025-11-17 10:37:53 --> Router Class Initialized
INFO - 2025-11-17 10:37:53 --> Output Class Initialized
INFO - 2025-11-17 10:37:53 --> Security Class Initialized
DEBUG - 2025-11-17 10:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-17 10:37:53 --> Input Class Initialized
INFO - 2025-11-17 10:37:53 --> Language Class Initialized
INFO - 2025-11-17 10:37:53 --> Loader Class Initialized
INFO - 2025-11-17 10:37:53 --> Helper loaded: url_helper
INFO - 2025-11-17 10:37:53 --> Database Driver Class Initialized
DEBUG - 2025-11-17 10:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-17 10:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-17 10:37:53 --> Helper loaded: form_helper
INFO - 2025-11-17 10:37:53 --> Form Validation Class Initialized
INFO - 2025-11-17 10:37:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-17 10:37:53 --> Pagination Class Initialized
INFO - 2025-11-17 10:37:53 --> Model "Common" initialized
INFO - 2025-11-17 10:37:53 --> Model "Ren_model" initialized
INFO - 2025-11-17 10:37:53 --> Model "SGODModel" initialized
INFO - 2025-11-17 10:37:53 --> Controller Class Initialized
INFO - 2025-11-17 10:37:53 --> Model "Login_model" initialized
INFO - 2025-11-17 10:37:53 --> Model "SettingsModel" initialized
DEBUG - 2025-11-17 10:37:53 --> Session class already loaded. Second attempt ignored.
INFO - 2025-11-17 10:37:54 --> File loaded: C:\xampp\htdocs\demo_system\application\views\home_page.php
INFO - 2025-11-17 10:37:54 --> Final output sent to browser
DEBUG - 2025-11-17 10:37:54 --> Total execution time: 0.2092
