<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-11-15 14:19:54 --> Config Class Initialized
INFO - 2025-11-15 14:19:54 --> Hooks Class Initialized
DEBUG - 2025-11-15 14:19:54 --> UTF-8 Support Enabled
INFO - 2025-11-15 14:19:54 --> Utf8 Class Initialized
INFO - 2025-11-15 14:19:54 --> URI Class Initialized
DEBUG - 2025-11-15 14:19:54 --> No URI present. Default controller set.
INFO - 2025-11-15 14:19:54 --> Router Class Initialized
INFO - 2025-11-15 14:19:54 --> Output Class Initialized
INFO - 2025-11-15 14:19:54 --> Security Class Initialized
DEBUG - 2025-11-15 14:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 14:19:54 --> Input Class Initialized
INFO - 2025-11-15 14:19:54 --> Language Class Initialized
INFO - 2025-11-15 14:19:54 --> Loader Class Initialized
INFO - 2025-11-15 14:19:54 --> Helper loaded: url_helper
INFO - 2025-11-15 14:19:54 --> Database Driver Class Initialized
DEBUG - 2025-11-15 14:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 14:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 14:19:54 --> Helper loaded: form_helper
INFO - 2025-11-15 14:19:54 --> Form Validation Class Initialized
INFO - 2025-11-15 14:19:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 14:19:54 --> Pagination Class Initialized
INFO - 2025-11-15 14:19:54 --> Model "Common" initialized
INFO - 2025-11-15 14:19:54 --> Model "Ren_model" initialized
INFO - 2025-11-15 14:19:54 --> Model "SGODModel" initialized
INFO - 2025-11-15 14:19:54 --> Controller Class Initialized
INFO - 2025-11-15 14:19:54 --> Model "Login_model" initialized
INFO - 2025-11-15 14:19:54 --> Model "SettingsModel" initialized
DEBUG - 2025-11-15 14:19:54 --> Session class already loaded. Second attempt ignored.
INFO - 2025-11-15 14:19:54 --> File loaded: C:\xampp\htdocs\demo_system\application\views\home_page.php
INFO - 2025-11-15 14:19:54 --> Final output sent to browser
DEBUG - 2025-11-15 14:19:54 --> Total execution time: 0.0613
INFO - 2025-11-15 14:20:10 --> Config Class Initialized
INFO - 2025-11-15 14:20:10 --> Hooks Class Initialized
DEBUG - 2025-11-15 14:20:10 --> UTF-8 Support Enabled
INFO - 2025-11-15 14:20:10 --> Utf8 Class Initialized
INFO - 2025-11-15 14:20:10 --> URI Class Initialized
DEBUG - 2025-11-15 14:20:10 --> No URI present. Default controller set.
INFO - 2025-11-15 14:20:10 --> Router Class Initialized
INFO - 2025-11-15 14:20:10 --> Output Class Initialized
INFO - 2025-11-15 14:20:10 --> Security Class Initialized
DEBUG - 2025-11-15 14:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 14:20:10 --> Input Class Initialized
INFO - 2025-11-15 14:20:10 --> Language Class Initialized
INFO - 2025-11-15 14:20:10 --> Loader Class Initialized
INFO - 2025-11-15 14:20:10 --> Helper loaded: url_helper
INFO - 2025-11-15 14:20:10 --> Database Driver Class Initialized
DEBUG - 2025-11-15 14:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 14:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 14:20:10 --> Helper loaded: form_helper
INFO - 2025-11-15 14:20:10 --> Form Validation Class Initialized
INFO - 2025-11-15 14:20:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 14:20:10 --> Pagination Class Initialized
INFO - 2025-11-15 14:20:10 --> Model "Common" initialized
INFO - 2025-11-15 14:20:10 --> Model "Ren_model" initialized
INFO - 2025-11-15 14:20:10 --> Model "SGODModel" initialized
INFO - 2025-11-15 14:20:10 --> Controller Class Initialized
INFO - 2025-11-15 14:20:10 --> Model "Login_model" initialized
INFO - 2025-11-15 14:20:10 --> Model "SettingsModel" initialized
DEBUG - 2025-11-15 14:20:10 --> Session class already loaded. Second attempt ignored.
INFO - 2025-11-15 14:20:10 --> File loaded: C:\xampp\htdocs\demo_system\application\views\home_page.php
INFO - 2025-11-15 14:20:10 --> Final output sent to browser
DEBUG - 2025-11-15 14:20:10 --> Total execution time: 0.0689
INFO - 2025-11-15 14:36:03 --> Config Class Initialized
INFO - 2025-11-15 14:36:03 --> Hooks Class Initialized
DEBUG - 2025-11-15 14:36:03 --> UTF-8 Support Enabled
INFO - 2025-11-15 14:36:03 --> Utf8 Class Initialized
INFO - 2025-11-15 14:36:03 --> URI Class Initialized
DEBUG - 2025-11-15 14:36:03 --> No URI present. Default controller set.
INFO - 2025-11-15 14:36:03 --> Router Class Initialized
INFO - 2025-11-15 14:36:03 --> Output Class Initialized
INFO - 2025-11-15 14:36:03 --> Security Class Initialized
DEBUG - 2025-11-15 14:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 14:36:03 --> Input Class Initialized
INFO - 2025-11-15 14:36:03 --> Language Class Initialized
INFO - 2025-11-15 14:36:03 --> Loader Class Initialized
INFO - 2025-11-15 14:36:03 --> Helper loaded: url_helper
INFO - 2025-11-15 14:36:03 --> Database Driver Class Initialized
DEBUG - 2025-11-15 14:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 14:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 14:36:03 --> Helper loaded: form_helper
INFO - 2025-11-15 14:36:03 --> Form Validation Class Initialized
INFO - 2025-11-15 14:36:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 14:36:03 --> Pagination Class Initialized
INFO - 2025-11-15 14:36:03 --> Model "Common" initialized
INFO - 2025-11-15 14:36:03 --> Model "Ren_model" initialized
INFO - 2025-11-15 14:36:03 --> Model "SGODModel" initialized
INFO - 2025-11-15 14:36:03 --> Controller Class Initialized
INFO - 2025-11-15 14:36:03 --> Model "Login_model" initialized
INFO - 2025-11-15 14:36:03 --> Model "SettingsModel" initialized
DEBUG - 2025-11-15 14:36:03 --> Session class already loaded. Second attempt ignored.
INFO - 2025-11-15 14:36:03 --> File loaded: C:\xampp\htdocs\demo_system\application\views\home_page.php
INFO - 2025-11-15 14:36:03 --> Final output sent to browser
DEBUG - 2025-11-15 14:36:03 --> Total execution time: 0.0609
INFO - 2025-11-15 14:40:12 --> Config Class Initialized
INFO - 2025-11-15 14:40:12 --> Hooks Class Initialized
DEBUG - 2025-11-15 14:40:12 --> UTF-8 Support Enabled
INFO - 2025-11-15 14:40:12 --> Utf8 Class Initialized
INFO - 2025-11-15 14:40:12 --> URI Class Initialized
DEBUG - 2025-11-15 14:40:12 --> No URI present. Default controller set.
INFO - 2025-11-15 14:40:12 --> Router Class Initialized
INFO - 2025-11-15 14:40:12 --> Output Class Initialized
INFO - 2025-11-15 14:40:12 --> Security Class Initialized
DEBUG - 2025-11-15 14:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 14:40:12 --> Input Class Initialized
INFO - 2025-11-15 14:40:12 --> Language Class Initialized
INFO - 2025-11-15 14:40:12 --> Loader Class Initialized
INFO - 2025-11-15 14:40:12 --> Helper loaded: url_helper
INFO - 2025-11-15 14:40:12 --> Database Driver Class Initialized
DEBUG - 2025-11-15 14:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 14:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 14:40:12 --> Helper loaded: form_helper
INFO - 2025-11-15 14:40:12 --> Form Validation Class Initialized
INFO - 2025-11-15 14:40:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 14:40:12 --> Pagination Class Initialized
INFO - 2025-11-15 14:40:12 --> Model "Common" initialized
INFO - 2025-11-15 14:40:12 --> Model "Ren_model" initialized
INFO - 2025-11-15 14:40:12 --> Model "SGODModel" initialized
INFO - 2025-11-15 14:40:12 --> Controller Class Initialized
INFO - 2025-11-15 14:40:12 --> Model "Login_model" initialized
INFO - 2025-11-15 14:40:12 --> Model "SettingsModel" initialized
DEBUG - 2025-11-15 14:40:12 --> Session class already loaded. Second attempt ignored.
INFO - 2025-11-15 14:40:12 --> File loaded: C:\xampp\htdocs\demo_system\application\views\home_page.php
INFO - 2025-11-15 14:40:12 --> Final output sent to browser
DEBUG - 2025-11-15 14:40:12 --> Total execution time: 0.0486
INFO - 2025-11-15 14:50:47 --> Config Class Initialized
INFO - 2025-11-15 14:50:47 --> Hooks Class Initialized
DEBUG - 2025-11-15 14:50:47 --> UTF-8 Support Enabled
INFO - 2025-11-15 14:50:47 --> Utf8 Class Initialized
INFO - 2025-11-15 14:50:47 --> URI Class Initialized
DEBUG - 2025-11-15 14:50:47 --> No URI present. Default controller set.
INFO - 2025-11-15 14:50:47 --> Router Class Initialized
INFO - 2025-11-15 14:50:47 --> Output Class Initialized
INFO - 2025-11-15 14:50:47 --> Security Class Initialized
DEBUG - 2025-11-15 14:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 14:50:47 --> Input Class Initialized
INFO - 2025-11-15 14:50:47 --> Language Class Initialized
INFO - 2025-11-15 14:50:47 --> Loader Class Initialized
INFO - 2025-11-15 14:50:47 --> Helper loaded: url_helper
INFO - 2025-11-15 14:50:47 --> Database Driver Class Initialized
DEBUG - 2025-11-15 14:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 14:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 14:50:47 --> Helper loaded: form_helper
INFO - 2025-11-15 14:50:47 --> Form Validation Class Initialized
INFO - 2025-11-15 14:50:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 14:50:47 --> Pagination Class Initialized
INFO - 2025-11-15 14:50:47 --> Model "Common" initialized
INFO - 2025-11-15 14:50:47 --> Model "Ren_model" initialized
INFO - 2025-11-15 14:50:47 --> Model "SGODModel" initialized
INFO - 2025-11-15 14:50:47 --> Controller Class Initialized
INFO - 2025-11-15 14:50:47 --> Model "Login_model" initialized
INFO - 2025-11-15 14:50:47 --> Model "SettingsModel" initialized
DEBUG - 2025-11-15 14:50:47 --> Session class already loaded. Second attempt ignored.
INFO - 2025-11-15 14:50:47 --> File loaded: C:\xampp\htdocs\demo_system\application\views\home_page.php
INFO - 2025-11-15 14:50:47 --> Final output sent to browser
DEBUG - 2025-11-15 14:50:47 --> Total execution time: 0.0519
INFO - 2025-11-15 14:55:44 --> Config Class Initialized
INFO - 2025-11-15 14:55:44 --> Hooks Class Initialized
DEBUG - 2025-11-15 14:55:44 --> UTF-8 Support Enabled
INFO - 2025-11-15 14:55:44 --> Utf8 Class Initialized
INFO - 2025-11-15 14:55:44 --> URI Class Initialized
INFO - 2025-11-15 14:55:44 --> Router Class Initialized
INFO - 2025-11-15 14:55:44 --> Output Class Initialized
INFO - 2025-11-15 14:55:44 --> Security Class Initialized
DEBUG - 2025-11-15 14:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 14:55:44 --> Input Class Initialized
INFO - 2025-11-15 14:55:44 --> Language Class Initialized
INFO - 2025-11-15 14:55:44 --> Loader Class Initialized
INFO - 2025-11-15 14:55:44 --> Helper loaded: url_helper
INFO - 2025-11-15 14:55:44 --> Database Driver Class Initialized
DEBUG - 2025-11-15 14:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 14:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 14:55:44 --> Helper loaded: form_helper
INFO - 2025-11-15 14:55:44 --> Form Validation Class Initialized
INFO - 2025-11-15 14:55:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 14:55:44 --> Pagination Class Initialized
INFO - 2025-11-15 14:55:44 --> Model "Common" initialized
INFO - 2025-11-15 14:55:44 --> Model "Ren_model" initialized
INFO - 2025-11-15 14:55:44 --> Model "SGODModel" initialized
INFO - 2025-11-15 14:55:44 --> Controller Class Initialized
DEBUG - 2025-11-15 14:55:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 14:55:44 --> Model "StudentModel" initialized
INFO - 2025-11-15 14:55:44 --> Model "SettingsModel" initialized
INFO - 2025-11-15 14:55:44 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 14:55:44 --> Model "InstructorModel" initialized
INFO - 2025-11-15 14:55:44 --> Model "LibraryModel" initialized
INFO - 2025-11-15 14:55:44 --> Model "Login_model" initialized
INFO - 2025-11-15 14:55:44 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 14:55:44 --> Final output sent to browser
DEBUG - 2025-11-15 14:55:44 --> Total execution time: 0.0957
INFO - 2025-11-15 14:55:44 --> Config Class Initialized
INFO - 2025-11-15 14:55:44 --> Hooks Class Initialized
DEBUG - 2025-11-15 14:55:44 --> UTF-8 Support Enabled
INFO - 2025-11-15 14:55:44 --> Utf8 Class Initialized
INFO - 2025-11-15 14:55:44 --> URI Class Initialized
INFO - 2025-11-15 14:55:44 --> Router Class Initialized
INFO - 2025-11-15 14:55:44 --> Output Class Initialized
INFO - 2025-11-15 14:55:44 --> Security Class Initialized
DEBUG - 2025-11-15 14:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 14:55:44 --> Input Class Initialized
INFO - 2025-11-15 14:55:44 --> Language Class Initialized
ERROR - 2025-11-15 14:55:44 --> 404 Page Not Found: Ren/assets
INFO - 2025-11-15 15:00:15 --> Config Class Initialized
INFO - 2025-11-15 15:00:15 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:00:15 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:00:15 --> Utf8 Class Initialized
INFO - 2025-11-15 15:00:15 --> URI Class Initialized
INFO - 2025-11-15 15:00:15 --> Router Class Initialized
INFO - 2025-11-15 15:00:15 --> Output Class Initialized
INFO - 2025-11-15 15:00:15 --> Security Class Initialized
DEBUG - 2025-11-15 15:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:00:15 --> Input Class Initialized
INFO - 2025-11-15 15:00:15 --> Language Class Initialized
INFO - 2025-11-15 15:00:15 --> Loader Class Initialized
INFO - 2025-11-15 15:00:15 --> Helper loaded: url_helper
INFO - 2025-11-15 15:00:15 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:00:15 --> Helper loaded: form_helper
INFO - 2025-11-15 15:00:15 --> Form Validation Class Initialized
INFO - 2025-11-15 15:00:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:00:15 --> Pagination Class Initialized
INFO - 2025-11-15 15:00:15 --> Model "Common" initialized
INFO - 2025-11-15 15:00:15 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:00:15 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:00:15 --> Controller Class Initialized
DEBUG - 2025-11-15 15:00:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:00:15 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:00:15 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:00:15 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:00:15 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:00:15 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:00:15 --> Model "Login_model" initialized
INFO - 2025-11-15 15:00:15 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 15:00:15 --> Final output sent to browser
DEBUG - 2025-11-15 15:00:15 --> Total execution time: 0.0731
INFO - 2025-11-15 15:00:15 --> Config Class Initialized
INFO - 2025-11-15 15:00:15 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:00:15 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:00:15 --> Utf8 Class Initialized
INFO - 2025-11-15 15:00:15 --> URI Class Initialized
INFO - 2025-11-15 15:00:15 --> Router Class Initialized
INFO - 2025-11-15 15:00:15 --> Output Class Initialized
INFO - 2025-11-15 15:00:15 --> Security Class Initialized
DEBUG - 2025-11-15 15:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:00:15 --> Input Class Initialized
INFO - 2025-11-15 15:00:15 --> Language Class Initialized
ERROR - 2025-11-15 15:00:15 --> 404 Page Not Found: Ren/assets
INFO - 2025-11-15 15:00:17 --> Config Class Initialized
INFO - 2025-11-15 15:00:17 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:00:17 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:00:17 --> Utf8 Class Initialized
INFO - 2025-11-15 15:00:17 --> URI Class Initialized
INFO - 2025-11-15 15:00:17 --> Router Class Initialized
INFO - 2025-11-15 15:00:18 --> Output Class Initialized
INFO - 2025-11-15 15:00:18 --> Security Class Initialized
DEBUG - 2025-11-15 15:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:00:18 --> Input Class Initialized
INFO - 2025-11-15 15:00:18 --> Language Class Initialized
INFO - 2025-11-15 15:00:18 --> Loader Class Initialized
INFO - 2025-11-15 15:00:18 --> Helper loaded: url_helper
INFO - 2025-11-15 15:00:18 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:00:18 --> Helper loaded: form_helper
INFO - 2025-11-15 15:00:18 --> Form Validation Class Initialized
INFO - 2025-11-15 15:00:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:00:18 --> Pagination Class Initialized
INFO - 2025-11-15 15:00:18 --> Model "Common" initialized
INFO - 2025-11-15 15:00:18 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:00:18 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:00:18 --> Controller Class Initialized
DEBUG - 2025-11-15 15:00:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:00:18 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:00:18 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:00:18 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:00:18 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:00:18 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:00:18 --> Model "Login_model" initialized
INFO - 2025-11-15 15:00:18 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 15:00:18 --> Final output sent to browser
DEBUG - 2025-11-15 15:00:18 --> Total execution time: 0.0570
INFO - 2025-11-15 15:00:18 --> Config Class Initialized
INFO - 2025-11-15 15:00:18 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:00:18 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:00:18 --> Utf8 Class Initialized
INFO - 2025-11-15 15:00:18 --> URI Class Initialized
INFO - 2025-11-15 15:00:18 --> Router Class Initialized
INFO - 2025-11-15 15:00:18 --> Output Class Initialized
INFO - 2025-11-15 15:00:18 --> Security Class Initialized
DEBUG - 2025-11-15 15:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:00:18 --> Input Class Initialized
INFO - 2025-11-15 15:00:18 --> Language Class Initialized
ERROR - 2025-11-15 15:00:18 --> 404 Page Not Found: Ren/assets
INFO - 2025-11-15 15:00:19 --> Config Class Initialized
INFO - 2025-11-15 15:00:19 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:00:19 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:00:19 --> Utf8 Class Initialized
INFO - 2025-11-15 15:00:19 --> URI Class Initialized
INFO - 2025-11-15 15:00:19 --> Router Class Initialized
INFO - 2025-11-15 15:00:19 --> Output Class Initialized
INFO - 2025-11-15 15:00:19 --> Security Class Initialized
DEBUG - 2025-11-15 15:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:00:19 --> Input Class Initialized
INFO - 2025-11-15 15:00:19 --> Language Class Initialized
INFO - 2025-11-15 15:00:19 --> Loader Class Initialized
INFO - 2025-11-15 15:00:19 --> Helper loaded: url_helper
INFO - 2025-11-15 15:00:19 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:00:19 --> Helper loaded: form_helper
INFO - 2025-11-15 15:00:19 --> Form Validation Class Initialized
INFO - 2025-11-15 15:00:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:00:19 --> Pagination Class Initialized
INFO - 2025-11-15 15:00:19 --> Model "Common" initialized
INFO - 2025-11-15 15:00:19 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:00:19 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:00:19 --> Controller Class Initialized
DEBUG - 2025-11-15 15:00:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:00:19 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:00:19 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:00:19 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:00:19 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:00:19 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:00:19 --> Model "Login_model" initialized
INFO - 2025-11-15 15:00:19 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 15:00:19 --> Final output sent to browser
DEBUG - 2025-11-15 15:00:19 --> Total execution time: 0.0575
INFO - 2025-11-15 15:00:19 --> Config Class Initialized
INFO - 2025-11-15 15:00:19 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:00:19 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:00:19 --> Utf8 Class Initialized
INFO - 2025-11-15 15:00:19 --> URI Class Initialized
INFO - 2025-11-15 15:00:19 --> Router Class Initialized
INFO - 2025-11-15 15:00:19 --> Output Class Initialized
INFO - 2025-11-15 15:00:19 --> Security Class Initialized
DEBUG - 2025-11-15 15:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:00:19 --> Input Class Initialized
INFO - 2025-11-15 15:00:19 --> Language Class Initialized
ERROR - 2025-11-15 15:00:19 --> 404 Page Not Found: Ren/assets
INFO - 2025-11-15 15:00:19 --> Config Class Initialized
INFO - 2025-11-15 15:00:19 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:00:19 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:00:19 --> Utf8 Class Initialized
INFO - 2025-11-15 15:00:19 --> URI Class Initialized
INFO - 2025-11-15 15:00:19 --> Router Class Initialized
INFO - 2025-11-15 15:00:19 --> Output Class Initialized
INFO - 2025-11-15 15:00:19 --> Security Class Initialized
DEBUG - 2025-11-15 15:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:00:19 --> Input Class Initialized
INFO - 2025-11-15 15:00:19 --> Language Class Initialized
INFO - 2025-11-15 15:00:19 --> Loader Class Initialized
INFO - 2025-11-15 15:00:19 --> Helper loaded: url_helper
INFO - 2025-11-15 15:00:19 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:00:19 --> Helper loaded: form_helper
INFO - 2025-11-15 15:00:19 --> Form Validation Class Initialized
INFO - 2025-11-15 15:00:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:00:19 --> Pagination Class Initialized
INFO - 2025-11-15 15:00:19 --> Model "Common" initialized
INFO - 2025-11-15 15:00:19 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:00:19 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:00:19 --> Controller Class Initialized
DEBUG - 2025-11-15 15:00:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:00:19 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:00:19 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:00:19 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:00:19 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:00:19 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:00:19 --> Model "Login_model" initialized
INFO - 2025-11-15 15:00:19 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 15:00:19 --> Final output sent to browser
DEBUG - 2025-11-15 15:00:19 --> Total execution time: 0.0568
INFO - 2025-11-15 15:00:19 --> Config Class Initialized
INFO - 2025-11-15 15:00:19 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:00:19 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:00:19 --> Utf8 Class Initialized
INFO - 2025-11-15 15:00:19 --> URI Class Initialized
INFO - 2025-11-15 15:00:19 --> Router Class Initialized
INFO - 2025-11-15 15:00:19 --> Output Class Initialized
INFO - 2025-11-15 15:00:19 --> Security Class Initialized
DEBUG - 2025-11-15 15:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:00:19 --> Input Class Initialized
INFO - 2025-11-15 15:00:19 --> Language Class Initialized
ERROR - 2025-11-15 15:00:19 --> 404 Page Not Found: Ren/assets
INFO - 2025-11-15 15:01:11 --> Config Class Initialized
INFO - 2025-11-15 15:01:11 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:01:11 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:01:11 --> Utf8 Class Initialized
INFO - 2025-11-15 15:01:11 --> URI Class Initialized
INFO - 2025-11-15 15:01:11 --> Router Class Initialized
INFO - 2025-11-15 15:01:11 --> Output Class Initialized
INFO - 2025-11-15 15:01:11 --> Security Class Initialized
DEBUG - 2025-11-15 15:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:01:11 --> Input Class Initialized
INFO - 2025-11-15 15:01:11 --> Language Class Initialized
INFO - 2025-11-15 15:01:11 --> Loader Class Initialized
INFO - 2025-11-15 15:01:11 --> Helper loaded: url_helper
INFO - 2025-11-15 15:01:11 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:01:11 --> Helper loaded: form_helper
INFO - 2025-11-15 15:01:11 --> Form Validation Class Initialized
INFO - 2025-11-15 15:01:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:01:11 --> Pagination Class Initialized
INFO - 2025-11-15 15:01:11 --> Model "Common" initialized
INFO - 2025-11-15 15:01:11 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:01:11 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:01:11 --> Controller Class Initialized
DEBUG - 2025-11-15 15:01:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:01:11 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:01:11 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:01:11 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:01:11 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:01:11 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:01:11 --> Model "Login_model" initialized
INFO - 2025-11-15 15:01:11 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 15:01:11 --> Final output sent to browser
DEBUG - 2025-11-15 15:01:11 --> Total execution time: 0.0618
INFO - 2025-11-15 15:01:12 --> Config Class Initialized
INFO - 2025-11-15 15:01:12 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:01:12 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:01:12 --> Utf8 Class Initialized
INFO - 2025-11-15 15:01:12 --> URI Class Initialized
INFO - 2025-11-15 15:01:12 --> Router Class Initialized
INFO - 2025-11-15 15:01:12 --> Output Class Initialized
INFO - 2025-11-15 15:01:12 --> Security Class Initialized
DEBUG - 2025-11-15 15:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:01:12 --> Input Class Initialized
INFO - 2025-11-15 15:01:12 --> Language Class Initialized
ERROR - 2025-11-15 15:01:12 --> 404 Page Not Found: Ren/assets
INFO - 2025-11-15 15:05:09 --> Config Class Initialized
INFO - 2025-11-15 15:05:09 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:05:09 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:05:09 --> Utf8 Class Initialized
INFO - 2025-11-15 15:05:09 --> URI Class Initialized
INFO - 2025-11-15 15:05:09 --> Router Class Initialized
INFO - 2025-11-15 15:05:09 --> Output Class Initialized
INFO - 2025-11-15 15:05:09 --> Security Class Initialized
DEBUG - 2025-11-15 15:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:05:09 --> Input Class Initialized
INFO - 2025-11-15 15:05:09 --> Language Class Initialized
INFO - 2025-11-15 15:05:09 --> Loader Class Initialized
INFO - 2025-11-15 15:05:09 --> Helper loaded: url_helper
INFO - 2025-11-15 15:05:09 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:05:09 --> Helper loaded: form_helper
INFO - 2025-11-15 15:05:09 --> Form Validation Class Initialized
INFO - 2025-11-15 15:05:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:05:09 --> Pagination Class Initialized
INFO - 2025-11-15 15:05:09 --> Model "Common" initialized
INFO - 2025-11-15 15:05:09 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:05:09 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:05:09 --> Controller Class Initialized
DEBUG - 2025-11-15 15:05:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:05:09 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:05:09 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:05:09 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:05:09 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:05:09 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:05:09 --> Model "Login_model" initialized
INFO - 2025-11-15 15:05:09 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 15:05:09 --> Final output sent to browser
DEBUG - 2025-11-15 15:05:09 --> Total execution time: 0.0667
INFO - 2025-11-15 15:05:09 --> Config Class Initialized
INFO - 2025-11-15 15:05:09 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:05:09 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:05:09 --> Utf8 Class Initialized
INFO - 2025-11-15 15:05:09 --> URI Class Initialized
INFO - 2025-11-15 15:05:09 --> Router Class Initialized
INFO - 2025-11-15 15:05:09 --> Output Class Initialized
INFO - 2025-11-15 15:05:09 --> Security Class Initialized
DEBUG - 2025-11-15 15:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:05:09 --> Input Class Initialized
INFO - 2025-11-15 15:05:09 --> Language Class Initialized
ERROR - 2025-11-15 15:05:09 --> 404 Page Not Found: Ren/assets
INFO - 2025-11-15 15:05:10 --> Config Class Initialized
INFO - 2025-11-15 15:05:10 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:05:10 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:05:10 --> Utf8 Class Initialized
INFO - 2025-11-15 15:05:10 --> URI Class Initialized
INFO - 2025-11-15 15:05:10 --> Router Class Initialized
INFO - 2025-11-15 15:05:10 --> Output Class Initialized
INFO - 2025-11-15 15:05:10 --> Security Class Initialized
DEBUG - 2025-11-15 15:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:05:10 --> Input Class Initialized
INFO - 2025-11-15 15:05:10 --> Language Class Initialized
INFO - 2025-11-15 15:05:10 --> Loader Class Initialized
INFO - 2025-11-15 15:05:10 --> Helper loaded: url_helper
INFO - 2025-11-15 15:05:10 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:05:10 --> Helper loaded: form_helper
INFO - 2025-11-15 15:05:10 --> Form Validation Class Initialized
INFO - 2025-11-15 15:05:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:05:10 --> Pagination Class Initialized
INFO - 2025-11-15 15:05:10 --> Model "Common" initialized
INFO - 2025-11-15 15:05:10 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:05:10 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:05:10 --> Controller Class Initialized
DEBUG - 2025-11-15 15:05:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:05:10 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:05:10 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:05:10 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:05:10 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:05:10 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:05:10 --> Model "Login_model" initialized
INFO - 2025-11-15 15:05:10 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 15:05:10 --> Final output sent to browser
DEBUG - 2025-11-15 15:05:10 --> Total execution time: 0.0702
INFO - 2025-11-15 15:05:10 --> Config Class Initialized
INFO - 2025-11-15 15:05:10 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:05:10 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:05:10 --> Utf8 Class Initialized
INFO - 2025-11-15 15:05:10 --> URI Class Initialized
INFO - 2025-11-15 15:05:10 --> Router Class Initialized
INFO - 2025-11-15 15:05:10 --> Output Class Initialized
INFO - 2025-11-15 15:05:10 --> Security Class Initialized
DEBUG - 2025-11-15 15:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:05:10 --> Input Class Initialized
INFO - 2025-11-15 15:05:10 --> Language Class Initialized
ERROR - 2025-11-15 15:05:10 --> 404 Page Not Found: Ren/assets
INFO - 2025-11-15 15:05:11 --> Config Class Initialized
INFO - 2025-11-15 15:05:11 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:05:11 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:05:11 --> Utf8 Class Initialized
INFO - 2025-11-15 15:05:11 --> URI Class Initialized
INFO - 2025-11-15 15:05:11 --> Router Class Initialized
INFO - 2025-11-15 15:05:11 --> Output Class Initialized
INFO - 2025-11-15 15:05:11 --> Security Class Initialized
DEBUG - 2025-11-15 15:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:05:11 --> Input Class Initialized
INFO - 2025-11-15 15:05:11 --> Language Class Initialized
INFO - 2025-11-15 15:05:11 --> Loader Class Initialized
INFO - 2025-11-15 15:05:11 --> Helper loaded: url_helper
INFO - 2025-11-15 15:05:11 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:05:11 --> Helper loaded: form_helper
INFO - 2025-11-15 15:05:11 --> Form Validation Class Initialized
INFO - 2025-11-15 15:05:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:05:11 --> Pagination Class Initialized
INFO - 2025-11-15 15:05:11 --> Model "Common" initialized
INFO - 2025-11-15 15:05:11 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:05:11 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:05:11 --> Controller Class Initialized
DEBUG - 2025-11-15 15:05:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:05:11 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:05:11 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:05:11 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:05:11 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:05:11 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:05:11 --> Model "Login_model" initialized
INFO - 2025-11-15 15:05:11 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 15:05:11 --> Final output sent to browser
DEBUG - 2025-11-15 15:05:11 --> Total execution time: 0.0730
INFO - 2025-11-15 15:05:12 --> Config Class Initialized
INFO - 2025-11-15 15:05:12 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:05:12 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:05:12 --> Utf8 Class Initialized
INFO - 2025-11-15 15:05:12 --> URI Class Initialized
INFO - 2025-11-15 15:05:12 --> Router Class Initialized
INFO - 2025-11-15 15:05:12 --> Output Class Initialized
INFO - 2025-11-15 15:05:12 --> Security Class Initialized
DEBUG - 2025-11-15 15:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:05:12 --> Input Class Initialized
INFO - 2025-11-15 15:05:12 --> Language Class Initialized
ERROR - 2025-11-15 15:05:12 --> 404 Page Not Found: Ren/assets
INFO - 2025-11-15 15:05:12 --> Config Class Initialized
INFO - 2025-11-15 15:05:12 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:05:12 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:05:12 --> Utf8 Class Initialized
INFO - 2025-11-15 15:05:12 --> URI Class Initialized
INFO - 2025-11-15 15:05:12 --> Router Class Initialized
INFO - 2025-11-15 15:05:12 --> Output Class Initialized
INFO - 2025-11-15 15:05:12 --> Security Class Initialized
DEBUG - 2025-11-15 15:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:05:12 --> Input Class Initialized
INFO - 2025-11-15 15:05:12 --> Language Class Initialized
INFO - 2025-11-15 15:05:12 --> Loader Class Initialized
INFO - 2025-11-15 15:05:12 --> Helper loaded: url_helper
INFO - 2025-11-15 15:05:12 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:05:12 --> Helper loaded: form_helper
INFO - 2025-11-15 15:05:12 --> Form Validation Class Initialized
INFO - 2025-11-15 15:05:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:05:12 --> Pagination Class Initialized
INFO - 2025-11-15 15:05:12 --> Model "Common" initialized
INFO - 2025-11-15 15:05:12 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:05:12 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:05:12 --> Controller Class Initialized
DEBUG - 2025-11-15 15:05:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:05:12 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:05:12 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:05:12 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:05:12 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:05:12 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:05:12 --> Model "Login_model" initialized
INFO - 2025-11-15 15:05:12 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 15:05:12 --> Final output sent to browser
DEBUG - 2025-11-15 15:05:12 --> Total execution time: 0.0764
INFO - 2025-11-15 15:05:12 --> Config Class Initialized
INFO - 2025-11-15 15:05:12 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:05:12 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:05:12 --> Utf8 Class Initialized
INFO - 2025-11-15 15:05:12 --> URI Class Initialized
INFO - 2025-11-15 15:05:12 --> Router Class Initialized
INFO - 2025-11-15 15:05:12 --> Output Class Initialized
INFO - 2025-11-15 15:05:12 --> Security Class Initialized
DEBUG - 2025-11-15 15:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:05:12 --> Input Class Initialized
INFO - 2025-11-15 15:05:12 --> Language Class Initialized
ERROR - 2025-11-15 15:05:12 --> 404 Page Not Found: Ren/assets
INFO - 2025-11-15 15:05:13 --> Config Class Initialized
INFO - 2025-11-15 15:05:13 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:05:13 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:05:13 --> Utf8 Class Initialized
INFO - 2025-11-15 15:05:13 --> URI Class Initialized
INFO - 2025-11-15 15:05:13 --> Router Class Initialized
INFO - 2025-11-15 15:05:13 --> Output Class Initialized
INFO - 2025-11-15 15:05:13 --> Security Class Initialized
DEBUG - 2025-11-15 15:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:05:13 --> Input Class Initialized
INFO - 2025-11-15 15:05:13 --> Language Class Initialized
INFO - 2025-11-15 15:05:13 --> Loader Class Initialized
INFO - 2025-11-15 15:05:13 --> Helper loaded: url_helper
INFO - 2025-11-15 15:05:13 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:05:13 --> Helper loaded: form_helper
INFO - 2025-11-15 15:05:13 --> Form Validation Class Initialized
INFO - 2025-11-15 15:05:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:05:13 --> Pagination Class Initialized
INFO - 2025-11-15 15:05:13 --> Model "Common" initialized
INFO - 2025-11-15 15:05:13 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:05:13 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:05:13 --> Controller Class Initialized
DEBUG - 2025-11-15 15:05:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:05:13 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:05:13 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:05:13 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:05:13 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:05:13 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:05:13 --> Model "Login_model" initialized
INFO - 2025-11-15 15:05:13 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 15:05:13 --> Final output sent to browser
DEBUG - 2025-11-15 15:05:13 --> Total execution time: 0.0704
INFO - 2025-11-15 15:05:13 --> Config Class Initialized
INFO - 2025-11-15 15:05:13 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:05:13 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:05:13 --> Utf8 Class Initialized
INFO - 2025-11-15 15:05:13 --> URI Class Initialized
INFO - 2025-11-15 15:05:13 --> Router Class Initialized
INFO - 2025-11-15 15:05:13 --> Output Class Initialized
INFO - 2025-11-15 15:05:13 --> Security Class Initialized
DEBUG - 2025-11-15 15:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:05:13 --> Config Class Initialized
INFO - 2025-11-15 15:05:13 --> Input Class Initialized
INFO - 2025-11-15 15:05:13 --> Hooks Class Initialized
INFO - 2025-11-15 15:05:13 --> Language Class Initialized
DEBUG - 2025-11-15 15:05:13 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:05:13 --> Utf8 Class Initialized
ERROR - 2025-11-15 15:05:13 --> 404 Page Not Found: Ren/assets
INFO - 2025-11-15 15:05:13 --> URI Class Initialized
INFO - 2025-11-15 15:05:13 --> Router Class Initialized
INFO - 2025-11-15 15:05:13 --> Output Class Initialized
INFO - 2025-11-15 15:05:13 --> Security Class Initialized
DEBUG - 2025-11-15 15:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:05:13 --> Input Class Initialized
INFO - 2025-11-15 15:05:13 --> Language Class Initialized
INFO - 2025-11-15 15:05:13 --> Loader Class Initialized
INFO - 2025-11-15 15:05:13 --> Helper loaded: url_helper
INFO - 2025-11-15 15:05:13 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:05:13 --> Helper loaded: form_helper
INFO - 2025-11-15 15:05:13 --> Form Validation Class Initialized
INFO - 2025-11-15 15:05:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:05:13 --> Pagination Class Initialized
INFO - 2025-11-15 15:05:13 --> Model "Common" initialized
INFO - 2025-11-15 15:05:13 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:05:13 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:05:13 --> Controller Class Initialized
DEBUG - 2025-11-15 15:05:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:05:13 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:05:13 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:05:13 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:05:13 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:05:13 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:05:13 --> Model "Login_model" initialized
INFO - 2025-11-15 15:05:13 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 15:05:13 --> Final output sent to browser
DEBUG - 2025-11-15 15:05:13 --> Total execution time: 0.0781
INFO - 2025-11-15 15:05:13 --> Config Class Initialized
INFO - 2025-11-15 15:05:13 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:05:13 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:05:13 --> Utf8 Class Initialized
INFO - 2025-11-15 15:05:13 --> URI Class Initialized
INFO - 2025-11-15 15:05:13 --> Router Class Initialized
INFO - 2025-11-15 15:05:13 --> Output Class Initialized
INFO - 2025-11-15 15:05:13 --> Security Class Initialized
DEBUG - 2025-11-15 15:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:05:13 --> Input Class Initialized
INFO - 2025-11-15 15:05:13 --> Language Class Initialized
INFO - 2025-11-15 15:05:13 --> Config Class Initialized
INFO - 2025-11-15 15:05:13 --> Hooks Class Initialized
ERROR - 2025-11-15 15:05:13 --> 404 Page Not Found: Ren/assets
DEBUG - 2025-11-15 15:05:13 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:05:13 --> Utf8 Class Initialized
INFO - 2025-11-15 15:05:13 --> URI Class Initialized
INFO - 2025-11-15 15:05:13 --> Router Class Initialized
INFO - 2025-11-15 15:05:13 --> Output Class Initialized
INFO - 2025-11-15 15:05:13 --> Security Class Initialized
DEBUG - 2025-11-15 15:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:05:13 --> Input Class Initialized
INFO - 2025-11-15 15:05:13 --> Language Class Initialized
INFO - 2025-11-15 15:05:13 --> Loader Class Initialized
INFO - 2025-11-15 15:05:13 --> Helper loaded: url_helper
INFO - 2025-11-15 15:05:13 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:05:13 --> Helper loaded: form_helper
INFO - 2025-11-15 15:05:13 --> Form Validation Class Initialized
INFO - 2025-11-15 15:05:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:05:13 --> Pagination Class Initialized
INFO - 2025-11-15 15:05:13 --> Model "Common" initialized
INFO - 2025-11-15 15:05:13 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:05:13 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:05:13 --> Controller Class Initialized
DEBUG - 2025-11-15 15:05:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:05:13 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:05:13 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:05:13 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:05:13 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:05:13 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:05:13 --> Model "Login_model" initialized
INFO - 2025-11-15 15:05:13 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 15:05:13 --> Final output sent to browser
DEBUG - 2025-11-15 15:05:13 --> Total execution time: 0.0648
INFO - 2025-11-15 15:05:13 --> Config Class Initialized
INFO - 2025-11-15 15:05:13 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:05:13 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:05:13 --> Utf8 Class Initialized
INFO - 2025-11-15 15:05:13 --> URI Class Initialized
INFO - 2025-11-15 15:05:13 --> Router Class Initialized
INFO - 2025-11-15 15:05:13 --> Output Class Initialized
INFO - 2025-11-15 15:05:13 --> Security Class Initialized
DEBUG - 2025-11-15 15:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:05:13 --> Input Class Initialized
INFO - 2025-11-15 15:05:13 --> Language Class Initialized
ERROR - 2025-11-15 15:05:13 --> 404 Page Not Found: Ren/assets
INFO - 2025-11-15 15:05:13 --> Config Class Initialized
INFO - 2025-11-15 15:05:13 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:05:13 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:05:13 --> Utf8 Class Initialized
INFO - 2025-11-15 15:05:13 --> URI Class Initialized
INFO - 2025-11-15 15:05:13 --> Router Class Initialized
INFO - 2025-11-15 15:05:13 --> Output Class Initialized
INFO - 2025-11-15 15:05:13 --> Security Class Initialized
DEBUG - 2025-11-15 15:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:05:13 --> Input Class Initialized
INFO - 2025-11-15 15:05:13 --> Language Class Initialized
INFO - 2025-11-15 15:05:13 --> Loader Class Initialized
INFO - 2025-11-15 15:05:13 --> Helper loaded: url_helper
INFO - 2025-11-15 15:05:13 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:05:13 --> Helper loaded: form_helper
INFO - 2025-11-15 15:05:13 --> Form Validation Class Initialized
INFO - 2025-11-15 15:05:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:05:13 --> Pagination Class Initialized
INFO - 2025-11-15 15:05:13 --> Model "Common" initialized
INFO - 2025-11-15 15:05:13 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:05:13 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:05:13 --> Controller Class Initialized
DEBUG - 2025-11-15 15:05:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:05:13 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:05:13 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:05:13 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:05:13 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:05:13 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:05:13 --> Model "Login_model" initialized
INFO - 2025-11-15 15:05:13 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 15:05:13 --> Final output sent to browser
DEBUG - 2025-11-15 15:05:13 --> Total execution time: 0.0620
INFO - 2025-11-15 15:05:14 --> Config Class Initialized
INFO - 2025-11-15 15:05:14 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:05:14 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:05:14 --> Utf8 Class Initialized
INFO - 2025-11-15 15:05:14 --> URI Class Initialized
INFO - 2025-11-15 15:05:14 --> Router Class Initialized
INFO - 2025-11-15 15:05:14 --> Output Class Initialized
INFO - 2025-11-15 15:05:14 --> Security Class Initialized
DEBUG - 2025-11-15 15:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:05:14 --> Input Class Initialized
INFO - 2025-11-15 15:05:14 --> Language Class Initialized
INFO - 2025-11-15 15:05:14 --> Config Class Initialized
INFO - 2025-11-15 15:05:14 --> Hooks Class Initialized
ERROR - 2025-11-15 15:05:14 --> 404 Page Not Found: Ren/assets
DEBUG - 2025-11-15 15:05:14 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:05:14 --> Utf8 Class Initialized
INFO - 2025-11-15 15:05:14 --> URI Class Initialized
INFO - 2025-11-15 15:05:14 --> Router Class Initialized
INFO - 2025-11-15 15:05:14 --> Output Class Initialized
INFO - 2025-11-15 15:05:14 --> Security Class Initialized
DEBUG - 2025-11-15 15:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:05:14 --> Input Class Initialized
INFO - 2025-11-15 15:05:14 --> Language Class Initialized
INFO - 2025-11-15 15:05:14 --> Loader Class Initialized
INFO - 2025-11-15 15:05:14 --> Helper loaded: url_helper
INFO - 2025-11-15 15:05:14 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:05:14 --> Helper loaded: form_helper
INFO - 2025-11-15 15:05:14 --> Form Validation Class Initialized
INFO - 2025-11-15 15:05:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:05:14 --> Pagination Class Initialized
INFO - 2025-11-15 15:05:14 --> Model "Common" initialized
INFO - 2025-11-15 15:05:14 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:05:14 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:05:14 --> Controller Class Initialized
DEBUG - 2025-11-15 15:05:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:05:14 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:05:14 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:05:14 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:05:14 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:05:14 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:05:14 --> Model "Login_model" initialized
INFO - 2025-11-15 15:05:14 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 15:05:14 --> Final output sent to browser
DEBUG - 2025-11-15 15:05:14 --> Total execution time: 0.0564
INFO - 2025-11-15 15:05:14 --> Config Class Initialized
INFO - 2025-11-15 15:05:14 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:05:14 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:05:14 --> Utf8 Class Initialized
INFO - 2025-11-15 15:05:14 --> URI Class Initialized
INFO - 2025-11-15 15:05:14 --> Router Class Initialized
INFO - 2025-11-15 15:05:14 --> Output Class Initialized
INFO - 2025-11-15 15:05:14 --> Security Class Initialized
DEBUG - 2025-11-15 15:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:05:14 --> Input Class Initialized
INFO - 2025-11-15 15:05:14 --> Language Class Initialized
ERROR - 2025-11-15 15:05:14 --> 404 Page Not Found: Ren/assets
INFO - 2025-11-15 15:11:35 --> Config Class Initialized
INFO - 2025-11-15 15:11:35 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:11:35 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:11:35 --> Utf8 Class Initialized
INFO - 2025-11-15 15:11:35 --> URI Class Initialized
INFO - 2025-11-15 15:11:35 --> Router Class Initialized
INFO - 2025-11-15 15:11:35 --> Output Class Initialized
INFO - 2025-11-15 15:11:35 --> Security Class Initialized
DEBUG - 2025-11-15 15:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:11:35 --> Input Class Initialized
INFO - 2025-11-15 15:11:35 --> Language Class Initialized
INFO - 2025-11-15 15:11:35 --> Loader Class Initialized
INFO - 2025-11-15 15:11:35 --> Helper loaded: url_helper
INFO - 2025-11-15 15:11:35 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:11:35 --> Helper loaded: form_helper
INFO - 2025-11-15 15:11:35 --> Form Validation Class Initialized
INFO - 2025-11-15 15:11:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:11:35 --> Pagination Class Initialized
INFO - 2025-11-15 15:11:35 --> Model "Common" initialized
INFO - 2025-11-15 15:11:35 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:11:35 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:11:35 --> Controller Class Initialized
DEBUG - 2025-11-15 15:11:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:11:35 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:11:35 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:11:35 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:11:35 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:11:35 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:11:35 --> Model "Login_model" initialized
INFO - 2025-11-15 15:11:35 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 15:11:35 --> Final output sent to browser
DEBUG - 2025-11-15 15:11:35 --> Total execution time: 0.0571
INFO - 2025-11-15 15:11:35 --> Config Class Initialized
INFO - 2025-11-15 15:11:35 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:11:35 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:11:35 --> Utf8 Class Initialized
INFO - 2025-11-15 15:11:35 --> URI Class Initialized
INFO - 2025-11-15 15:11:35 --> Router Class Initialized
INFO - 2025-11-15 15:11:35 --> Output Class Initialized
INFO - 2025-11-15 15:11:35 --> Security Class Initialized
DEBUG - 2025-11-15 15:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:11:35 --> Input Class Initialized
INFO - 2025-11-15 15:11:35 --> Language Class Initialized
ERROR - 2025-11-15 15:11:35 --> 404 Page Not Found: Ren/assets
INFO - 2025-11-15 15:12:09 --> Config Class Initialized
INFO - 2025-11-15 15:12:09 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:12:09 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:12:09 --> Utf8 Class Initialized
INFO - 2025-11-15 15:12:09 --> URI Class Initialized
INFO - 2025-11-15 15:12:09 --> Router Class Initialized
INFO - 2025-11-15 15:12:09 --> Output Class Initialized
INFO - 2025-11-15 15:12:09 --> Security Class Initialized
DEBUG - 2025-11-15 15:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:12:09 --> Input Class Initialized
INFO - 2025-11-15 15:12:09 --> Language Class Initialized
INFO - 2025-11-15 15:12:09 --> Loader Class Initialized
INFO - 2025-11-15 15:12:09 --> Helper loaded: url_helper
INFO - 2025-11-15 15:12:09 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:12:09 --> Helper loaded: form_helper
INFO - 2025-11-15 15:12:09 --> Form Validation Class Initialized
INFO - 2025-11-15 15:12:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:12:09 --> Pagination Class Initialized
INFO - 2025-11-15 15:12:09 --> Model "Common" initialized
INFO - 2025-11-15 15:12:09 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:12:09 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:12:09 --> Controller Class Initialized
DEBUG - 2025-11-15 15:12:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:12:09 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:12:09 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:12:09 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:12:09 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:12:09 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:12:09 --> Model "Login_model" initialized
INFO - 2025-11-15 15:12:09 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 15:12:09 --> Final output sent to browser
DEBUG - 2025-11-15 15:12:09 --> Total execution time: 0.0978
INFO - 2025-11-15 15:12:09 --> Config Class Initialized
INFO - 2025-11-15 15:12:09 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:12:09 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:12:09 --> Utf8 Class Initialized
INFO - 2025-11-15 15:12:09 --> URI Class Initialized
INFO - 2025-11-15 15:12:09 --> Router Class Initialized
INFO - 2025-11-15 15:12:09 --> Output Class Initialized
INFO - 2025-11-15 15:12:09 --> Security Class Initialized
DEBUG - 2025-11-15 15:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:12:09 --> Input Class Initialized
INFO - 2025-11-15 15:12:09 --> Language Class Initialized
ERROR - 2025-11-15 15:12:09 --> 404 Page Not Found: Ren/assets
INFO - 2025-11-15 15:12:10 --> Config Class Initialized
INFO - 2025-11-15 15:12:10 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:12:10 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:12:10 --> Utf8 Class Initialized
INFO - 2025-11-15 15:12:10 --> URI Class Initialized
INFO - 2025-11-15 15:12:10 --> Router Class Initialized
INFO - 2025-11-15 15:12:10 --> Output Class Initialized
INFO - 2025-11-15 15:12:10 --> Security Class Initialized
DEBUG - 2025-11-15 15:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:12:10 --> Input Class Initialized
INFO - 2025-11-15 15:12:10 --> Language Class Initialized
INFO - 2025-11-15 15:12:10 --> Loader Class Initialized
INFO - 2025-11-15 15:12:10 --> Helper loaded: url_helper
INFO - 2025-11-15 15:12:10 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:12:10 --> Helper loaded: form_helper
INFO - 2025-11-15 15:12:10 --> Form Validation Class Initialized
INFO - 2025-11-15 15:12:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:12:10 --> Pagination Class Initialized
INFO - 2025-11-15 15:12:10 --> Model "Common" initialized
INFO - 2025-11-15 15:12:10 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:12:10 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:12:10 --> Controller Class Initialized
DEBUG - 2025-11-15 15:12:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:12:10 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:12:10 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:12:10 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:12:10 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:12:10 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:12:10 --> Model "Login_model" initialized
INFO - 2025-11-15 15:12:10 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 15:12:10 --> Final output sent to browser
DEBUG - 2025-11-15 15:12:10 --> Total execution time: 0.0939
INFO - 2025-11-15 15:12:10 --> Config Class Initialized
INFO - 2025-11-15 15:12:10 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:12:10 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:12:10 --> Utf8 Class Initialized
INFO - 2025-11-15 15:12:10 --> URI Class Initialized
INFO - 2025-11-15 15:12:10 --> Router Class Initialized
INFO - 2025-11-15 15:12:10 --> Output Class Initialized
INFO - 2025-11-15 15:12:10 --> Security Class Initialized
DEBUG - 2025-11-15 15:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:12:10 --> Input Class Initialized
INFO - 2025-11-15 15:12:10 --> Language Class Initialized
ERROR - 2025-11-15 15:12:10 --> 404 Page Not Found: Ren/assets
INFO - 2025-11-15 15:12:11 --> Config Class Initialized
INFO - 2025-11-15 15:12:11 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:12:11 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:12:11 --> Utf8 Class Initialized
INFO - 2025-11-15 15:12:11 --> URI Class Initialized
INFO - 2025-11-15 15:12:11 --> Router Class Initialized
INFO - 2025-11-15 15:12:11 --> Output Class Initialized
INFO - 2025-11-15 15:12:11 --> Security Class Initialized
DEBUG - 2025-11-15 15:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:12:11 --> Input Class Initialized
INFO - 2025-11-15 15:12:11 --> Language Class Initialized
INFO - 2025-11-15 15:12:11 --> Loader Class Initialized
INFO - 2025-11-15 15:12:11 --> Helper loaded: url_helper
INFO - 2025-11-15 15:12:11 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:12:11 --> Helper loaded: form_helper
INFO - 2025-11-15 15:12:11 --> Form Validation Class Initialized
INFO - 2025-11-15 15:12:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:12:11 --> Pagination Class Initialized
INFO - 2025-11-15 15:12:11 --> Model "Common" initialized
INFO - 2025-11-15 15:12:11 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:12:11 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:12:11 --> Controller Class Initialized
DEBUG - 2025-11-15 15:12:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:12:11 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:12:11 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:12:11 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:12:11 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:12:11 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:12:11 --> Model "Login_model" initialized
INFO - 2025-11-15 15:12:11 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 15:12:11 --> Final output sent to browser
DEBUG - 2025-11-15 15:12:11 --> Total execution time: 0.0732
INFO - 2025-11-15 15:12:11 --> Config Class Initialized
INFO - 2025-11-15 15:12:11 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:12:11 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:12:11 --> Utf8 Class Initialized
INFO - 2025-11-15 15:12:11 --> URI Class Initialized
INFO - 2025-11-15 15:12:11 --> Router Class Initialized
INFO - 2025-11-15 15:12:11 --> Output Class Initialized
INFO - 2025-11-15 15:12:11 --> Security Class Initialized
DEBUG - 2025-11-15 15:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:12:11 --> Input Class Initialized
INFO - 2025-11-15 15:12:11 --> Language Class Initialized
ERROR - 2025-11-15 15:12:11 --> 404 Page Not Found: Ren/assets
INFO - 2025-11-15 15:12:22 --> Config Class Initialized
INFO - 2025-11-15 15:12:22 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:12:22 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:12:22 --> Utf8 Class Initialized
INFO - 2025-11-15 15:12:22 --> URI Class Initialized
INFO - 2025-11-15 15:12:22 --> Router Class Initialized
INFO - 2025-11-15 15:12:22 --> Output Class Initialized
INFO - 2025-11-15 15:12:22 --> Security Class Initialized
DEBUG - 2025-11-15 15:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:12:22 --> Input Class Initialized
INFO - 2025-11-15 15:12:22 --> Language Class Initialized
INFO - 2025-11-15 15:12:22 --> Loader Class Initialized
INFO - 2025-11-15 15:12:22 --> Helper loaded: url_helper
INFO - 2025-11-15 15:12:22 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:12:22 --> Helper loaded: form_helper
INFO - 2025-11-15 15:12:22 --> Form Validation Class Initialized
INFO - 2025-11-15 15:12:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:12:22 --> Pagination Class Initialized
INFO - 2025-11-15 15:12:22 --> Model "Common" initialized
INFO - 2025-11-15 15:12:22 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:12:22 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:12:22 --> Controller Class Initialized
DEBUG - 2025-11-15 15:12:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:12:22 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:12:22 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:12:22 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:12:22 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:12:22 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:12:22 --> Model "Login_model" initialized
INFO - 2025-11-15 15:12:22 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 15:12:22 --> Final output sent to browser
DEBUG - 2025-11-15 15:12:22 --> Total execution time: 0.0575
INFO - 2025-11-15 15:12:22 --> Config Class Initialized
INFO - 2025-11-15 15:12:22 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:12:22 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:12:22 --> Utf8 Class Initialized
INFO - 2025-11-15 15:12:22 --> URI Class Initialized
INFO - 2025-11-15 15:12:22 --> Router Class Initialized
INFO - 2025-11-15 15:12:22 --> Output Class Initialized
INFO - 2025-11-15 15:12:22 --> Security Class Initialized
DEBUG - 2025-11-15 15:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:12:22 --> Input Class Initialized
INFO - 2025-11-15 15:12:22 --> Language Class Initialized
ERROR - 2025-11-15 15:12:22 --> 404 Page Not Found: Ren/assets
INFO - 2025-11-15 15:20:33 --> Config Class Initialized
INFO - 2025-11-15 15:20:33 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:20:33 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:20:33 --> Utf8 Class Initialized
INFO - 2025-11-15 15:20:33 --> URI Class Initialized
INFO - 2025-11-15 15:20:33 --> Router Class Initialized
INFO - 2025-11-15 15:20:33 --> Output Class Initialized
INFO - 2025-11-15 15:20:33 --> Security Class Initialized
DEBUG - 2025-11-15 15:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:20:33 --> Input Class Initialized
INFO - 2025-11-15 15:20:33 --> Language Class Initialized
INFO - 2025-11-15 15:20:33 --> Loader Class Initialized
INFO - 2025-11-15 15:20:33 --> Helper loaded: url_helper
INFO - 2025-11-15 15:20:33 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:20:33 --> Helper loaded: form_helper
INFO - 2025-11-15 15:20:33 --> Form Validation Class Initialized
INFO - 2025-11-15 15:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:20:33 --> Pagination Class Initialized
INFO - 2025-11-15 15:20:33 --> Model "Common" initialized
INFO - 2025-11-15 15:20:33 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:20:33 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:20:33 --> Controller Class Initialized
DEBUG - 2025-11-15 15:20:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:20:33 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:20:33 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:20:33 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:20:33 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:20:33 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:20:33 --> Model "Login_model" initialized
INFO - 2025-11-15 15:20:33 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 15:20:33 --> Final output sent to browser
DEBUG - 2025-11-15 15:20:33 --> Total execution time: 0.0995
INFO - 2025-11-15 15:20:34 --> Config Class Initialized
INFO - 2025-11-15 15:20:34 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:20:34 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:20:34 --> Utf8 Class Initialized
INFO - 2025-11-15 15:20:34 --> URI Class Initialized
INFO - 2025-11-15 15:20:34 --> Router Class Initialized
INFO - 2025-11-15 15:20:34 --> Output Class Initialized
INFO - 2025-11-15 15:20:34 --> Security Class Initialized
DEBUG - 2025-11-15 15:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:20:34 --> Input Class Initialized
INFO - 2025-11-15 15:20:34 --> Language Class Initialized
ERROR - 2025-11-15 15:20:34 --> 404 Page Not Found: Ren/assets
INFO - 2025-11-15 15:22:21 --> Config Class Initialized
INFO - 2025-11-15 15:22:21 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:22:21 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:22:21 --> Utf8 Class Initialized
INFO - 2025-11-15 15:22:21 --> URI Class Initialized
INFO - 2025-11-15 15:22:21 --> Router Class Initialized
INFO - 2025-11-15 15:22:21 --> Output Class Initialized
INFO - 2025-11-15 15:22:21 --> Security Class Initialized
DEBUG - 2025-11-15 15:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:22:21 --> Input Class Initialized
INFO - 2025-11-15 15:22:21 --> Language Class Initialized
INFO - 2025-11-15 15:22:21 --> Loader Class Initialized
INFO - 2025-11-15 15:22:21 --> Helper loaded: url_helper
INFO - 2025-11-15 15:22:21 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:22:21 --> Helper loaded: form_helper
INFO - 2025-11-15 15:22:21 --> Form Validation Class Initialized
INFO - 2025-11-15 15:22:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:22:21 --> Pagination Class Initialized
INFO - 2025-11-15 15:22:21 --> Model "Common" initialized
INFO - 2025-11-15 15:22:21 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:22:21 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:22:21 --> Controller Class Initialized
DEBUG - 2025-11-15 15:22:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:22:21 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:22:21 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:22:21 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:22:21 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:22:21 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:22:21 --> Model "Login_model" initialized
INFO - 2025-11-15 15:22:21 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 15:22:21 --> Final output sent to browser
DEBUG - 2025-11-15 15:22:21 --> Total execution time: 0.0626
INFO - 2025-11-15 15:22:21 --> Config Class Initialized
INFO - 2025-11-15 15:22:21 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:22:21 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:22:21 --> Utf8 Class Initialized
INFO - 2025-11-15 15:22:21 --> URI Class Initialized
INFO - 2025-11-15 15:22:21 --> Router Class Initialized
INFO - 2025-11-15 15:22:21 --> Output Class Initialized
INFO - 2025-11-15 15:22:21 --> Security Class Initialized
DEBUG - 2025-11-15 15:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:22:21 --> Input Class Initialized
INFO - 2025-11-15 15:22:21 --> Language Class Initialized
ERROR - 2025-11-15 15:22:21 --> 404 Page Not Found: Ren/assets
INFO - 2025-11-15 15:22:22 --> Config Class Initialized
INFO - 2025-11-15 15:22:22 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:22:22 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:22:22 --> Utf8 Class Initialized
INFO - 2025-11-15 15:22:22 --> URI Class Initialized
INFO - 2025-11-15 15:22:22 --> Router Class Initialized
INFO - 2025-11-15 15:22:22 --> Output Class Initialized
INFO - 2025-11-15 15:22:22 --> Security Class Initialized
DEBUG - 2025-11-15 15:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:22:22 --> Input Class Initialized
INFO - 2025-11-15 15:22:22 --> Language Class Initialized
INFO - 2025-11-15 15:22:22 --> Loader Class Initialized
INFO - 2025-11-15 15:22:22 --> Helper loaded: url_helper
INFO - 2025-11-15 15:22:22 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:22:22 --> Helper loaded: form_helper
INFO - 2025-11-15 15:22:22 --> Form Validation Class Initialized
INFO - 2025-11-15 15:22:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:22:22 --> Pagination Class Initialized
INFO - 2025-11-15 15:22:22 --> Model "Common" initialized
INFO - 2025-11-15 15:22:22 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:22:22 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:22:22 --> Controller Class Initialized
DEBUG - 2025-11-15 15:22:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:22:22 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:22:22 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:22:22 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:22:22 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:22:22 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:22:22 --> Model "Login_model" initialized
INFO - 2025-11-15 15:22:22 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 15:22:22 --> Final output sent to browser
DEBUG - 2025-11-15 15:22:22 --> Total execution time: 0.0846
INFO - 2025-11-15 15:22:22 --> Config Class Initialized
INFO - 2025-11-15 15:22:22 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:22:22 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:22:22 --> Utf8 Class Initialized
INFO - 2025-11-15 15:22:22 --> URI Class Initialized
INFO - 2025-11-15 15:22:22 --> Router Class Initialized
INFO - 2025-11-15 15:22:22 --> Output Class Initialized
INFO - 2025-11-15 15:22:22 --> Security Class Initialized
DEBUG - 2025-11-15 15:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:22:22 --> Input Class Initialized
INFO - 2025-11-15 15:22:22 --> Language Class Initialized
ERROR - 2025-11-15 15:22:22 --> 404 Page Not Found: Ren/assets
INFO - 2025-11-15 15:22:23 --> Config Class Initialized
INFO - 2025-11-15 15:22:23 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:22:23 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:22:23 --> Utf8 Class Initialized
INFO - 2025-11-15 15:22:23 --> URI Class Initialized
INFO - 2025-11-15 15:22:23 --> Router Class Initialized
INFO - 2025-11-15 15:22:23 --> Output Class Initialized
INFO - 2025-11-15 15:22:23 --> Security Class Initialized
DEBUG - 2025-11-15 15:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:22:23 --> Input Class Initialized
INFO - 2025-11-15 15:22:23 --> Language Class Initialized
INFO - 2025-11-15 15:22:23 --> Loader Class Initialized
INFO - 2025-11-15 15:22:23 --> Helper loaded: url_helper
INFO - 2025-11-15 15:22:23 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:22:23 --> Helper loaded: form_helper
INFO - 2025-11-15 15:22:23 --> Form Validation Class Initialized
INFO - 2025-11-15 15:22:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:22:23 --> Pagination Class Initialized
INFO - 2025-11-15 15:22:23 --> Model "Common" initialized
INFO - 2025-11-15 15:22:23 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:22:23 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:22:23 --> Controller Class Initialized
DEBUG - 2025-11-15 15:22:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:22:23 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:22:23 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:22:23 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:22:23 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:22:23 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:22:23 --> Model "Login_model" initialized
INFO - 2025-11-15 15:22:23 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 15:22:23 --> Final output sent to browser
DEBUG - 2025-11-15 15:22:23 --> Total execution time: 0.0576
INFO - 2025-11-15 15:22:23 --> Config Class Initialized
INFO - 2025-11-15 15:22:23 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:22:23 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:22:23 --> Utf8 Class Initialized
INFO - 2025-11-15 15:22:23 --> URI Class Initialized
INFO - 2025-11-15 15:22:23 --> Router Class Initialized
INFO - 2025-11-15 15:22:23 --> Output Class Initialized
INFO - 2025-11-15 15:22:23 --> Security Class Initialized
DEBUG - 2025-11-15 15:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:22:23 --> Input Class Initialized
INFO - 2025-11-15 15:22:23 --> Language Class Initialized
ERROR - 2025-11-15 15:22:23 --> 404 Page Not Found: Ren/assets
INFO - 2025-11-15 15:28:17 --> Config Class Initialized
INFO - 2025-11-15 15:28:17 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:28:17 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:28:17 --> Utf8 Class Initialized
INFO - 2025-11-15 15:28:17 --> URI Class Initialized
INFO - 2025-11-15 15:28:17 --> Router Class Initialized
INFO - 2025-11-15 15:28:17 --> Output Class Initialized
INFO - 2025-11-15 15:28:17 --> Security Class Initialized
DEBUG - 2025-11-15 15:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:28:17 --> Input Class Initialized
INFO - 2025-11-15 15:28:17 --> Language Class Initialized
INFO - 2025-11-15 15:28:17 --> Loader Class Initialized
INFO - 2025-11-15 15:28:17 --> Helper loaded: url_helper
INFO - 2025-11-15 15:28:17 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:28:17 --> Helper loaded: form_helper
INFO - 2025-11-15 15:28:17 --> Form Validation Class Initialized
INFO - 2025-11-15 15:28:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:28:17 --> Pagination Class Initialized
INFO - 2025-11-15 15:28:17 --> Model "Common" initialized
INFO - 2025-11-15 15:28:17 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:28:17 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:28:17 --> Controller Class Initialized
INFO - 2025-11-15 15:28:17 --> Model "Login_model" initialized
INFO - 2025-11-15 15:28:17 --> Model "SettingsModel" initialized
DEBUG - 2025-11-15 15:28:17 --> Session class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:28:17 --> Config Class Initialized
INFO - 2025-11-15 15:28:17 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:28:17 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:28:17 --> Utf8 Class Initialized
INFO - 2025-11-15 15:28:17 --> URI Class Initialized
INFO - 2025-11-15 15:28:17 --> Router Class Initialized
INFO - 2025-11-15 15:28:17 --> Output Class Initialized
INFO - 2025-11-15 15:28:17 --> Security Class Initialized
DEBUG - 2025-11-15 15:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:28:17 --> Input Class Initialized
INFO - 2025-11-15 15:28:17 --> Language Class Initialized
INFO - 2025-11-15 15:28:17 --> Loader Class Initialized
INFO - 2025-11-15 15:28:18 --> Helper loaded: url_helper
INFO - 2025-11-15 15:28:18 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:28:18 --> Helper loaded: form_helper
INFO - 2025-11-15 15:28:18 --> Form Validation Class Initialized
INFO - 2025-11-15 15:28:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:28:18 --> Pagination Class Initialized
INFO - 2025-11-15 15:28:18 --> Model "Common" initialized
INFO - 2025-11-15 15:28:18 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:28:18 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:28:18 --> Controller Class Initialized
INFO - 2025-11-15 15:28:18 --> Model "Login_model" initialized
INFO - 2025-11-15 15:28:18 --> Model "SettingsModel" initialized
DEBUG - 2025-11-15 15:28:18 --> Session class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:28:18 --> File loaded: C:\xampp\htdocs\demo_system\application\views\home_page.php
INFO - 2025-11-15 15:28:18 --> Final output sent to browser
DEBUG - 2025-11-15 15:28:18 --> Total execution time: 0.0571
INFO - 2025-11-15 15:28:30 --> Config Class Initialized
INFO - 2025-11-15 15:28:30 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:28:30 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:28:30 --> Utf8 Class Initialized
INFO - 2025-11-15 15:28:30 --> URI Class Initialized
INFO - 2025-11-15 15:28:30 --> Router Class Initialized
INFO - 2025-11-15 15:28:30 --> Output Class Initialized
INFO - 2025-11-15 15:28:30 --> Security Class Initialized
DEBUG - 2025-11-15 15:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:28:30 --> Input Class Initialized
INFO - 2025-11-15 15:28:30 --> Language Class Initialized
ERROR - 2025-11-15 15:28:30 --> 404 Page Not Found: Login/index
INFO - 2025-11-15 15:28:32 --> Config Class Initialized
INFO - 2025-11-15 15:28:32 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:28:32 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:28:32 --> Utf8 Class Initialized
INFO - 2025-11-15 15:28:32 --> URI Class Initialized
INFO - 2025-11-15 15:28:32 --> Router Class Initialized
INFO - 2025-11-15 15:28:32 --> Output Class Initialized
INFO - 2025-11-15 15:28:32 --> Security Class Initialized
DEBUG - 2025-11-15 15:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:28:32 --> Input Class Initialized
INFO - 2025-11-15 15:28:32 --> Language Class Initialized
ERROR - 2025-11-15 15:28:32 --> 404 Page Not Found: Login/index
INFO - 2025-11-15 15:28:43 --> Config Class Initialized
INFO - 2025-11-15 15:28:43 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:28:43 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:28:43 --> Utf8 Class Initialized
INFO - 2025-11-15 15:28:43 --> URI Class Initialized
INFO - 2025-11-15 15:28:43 --> Router Class Initialized
INFO - 2025-11-15 15:28:43 --> Output Class Initialized
INFO - 2025-11-15 15:28:43 --> Security Class Initialized
DEBUG - 2025-11-15 15:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:28:43 --> Input Class Initialized
INFO - 2025-11-15 15:28:43 --> Language Class Initialized
ERROR - 2025-11-15 15:28:43 --> 404 Page Not Found: Login/index
INFO - 2025-11-15 15:28:44 --> Config Class Initialized
INFO - 2025-11-15 15:28:44 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:28:44 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:28:44 --> Utf8 Class Initialized
INFO - 2025-11-15 15:28:44 --> URI Class Initialized
INFO - 2025-11-15 15:28:44 --> Router Class Initialized
INFO - 2025-11-15 15:28:44 --> Output Class Initialized
INFO - 2025-11-15 15:28:44 --> Security Class Initialized
DEBUG - 2025-11-15 15:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:28:44 --> Input Class Initialized
INFO - 2025-11-15 15:28:44 --> Language Class Initialized
ERROR - 2025-11-15 15:28:44 --> 404 Page Not Found: Ren/stud_reports
INFO - 2025-11-15 15:28:45 --> Config Class Initialized
INFO - 2025-11-15 15:28:45 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:28:45 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:28:45 --> Utf8 Class Initialized
INFO - 2025-11-15 15:28:45 --> URI Class Initialized
INFO - 2025-11-15 15:28:45 --> Router Class Initialized
INFO - 2025-11-15 15:28:45 --> Output Class Initialized
INFO - 2025-11-15 15:28:45 --> Security Class Initialized
DEBUG - 2025-11-15 15:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:28:45 --> Input Class Initialized
INFO - 2025-11-15 15:28:45 --> Language Class Initialized
ERROR - 2025-11-15 15:28:45 --> 404 Page Not Found: Ren/stud_reports
INFO - 2025-11-15 15:28:45 --> Config Class Initialized
INFO - 2025-11-15 15:28:45 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:28:45 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:28:45 --> Utf8 Class Initialized
INFO - 2025-11-15 15:28:45 --> URI Class Initialized
INFO - 2025-11-15 15:28:45 --> Router Class Initialized
INFO - 2025-11-15 15:28:45 --> Output Class Initialized
INFO - 2025-11-15 15:28:45 --> Security Class Initialized
DEBUG - 2025-11-15 15:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:28:45 --> Input Class Initialized
INFO - 2025-11-15 15:28:45 --> Language Class Initialized
ERROR - 2025-11-15 15:28:45 --> 404 Page Not Found: /index
INFO - 2025-11-15 15:28:47 --> Config Class Initialized
INFO - 2025-11-15 15:28:47 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:28:47 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:28:47 --> Utf8 Class Initialized
INFO - 2025-11-15 15:28:47 --> URI Class Initialized
INFO - 2025-11-15 15:28:47 --> Router Class Initialized
INFO - 2025-11-15 15:28:47 --> Output Class Initialized
INFO - 2025-11-15 15:28:47 --> Security Class Initialized
DEBUG - 2025-11-15 15:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:28:47 --> Input Class Initialized
INFO - 2025-11-15 15:28:47 --> Language Class Initialized
ERROR - 2025-11-15 15:28:47 --> 404 Page Not Found: /index
INFO - 2025-11-15 15:28:47 --> Config Class Initialized
INFO - 2025-11-15 15:28:47 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:28:47 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:28:47 --> Utf8 Class Initialized
INFO - 2025-11-15 15:28:47 --> URI Class Initialized
INFO - 2025-11-15 15:28:47 --> Router Class Initialized
INFO - 2025-11-15 15:28:47 --> Output Class Initialized
INFO - 2025-11-15 15:28:47 --> Security Class Initialized
DEBUG - 2025-11-15 15:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:28:47 --> Input Class Initialized
INFO - 2025-11-15 15:28:47 --> Language Class Initialized
ERROR - 2025-11-15 15:28:47 --> 404 Page Not Found: /index
INFO - 2025-11-15 15:28:47 --> Config Class Initialized
INFO - 2025-11-15 15:28:47 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:28:47 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:28:47 --> Utf8 Class Initialized
INFO - 2025-11-15 15:28:47 --> URI Class Initialized
INFO - 2025-11-15 15:28:47 --> Router Class Initialized
INFO - 2025-11-15 15:28:47 --> Output Class Initialized
INFO - 2025-11-15 15:28:47 --> Security Class Initialized
DEBUG - 2025-11-15 15:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:28:47 --> Input Class Initialized
INFO - 2025-11-15 15:28:47 --> Language Class Initialized
ERROR - 2025-11-15 15:28:47 --> 404 Page Not Found: /index
INFO - 2025-11-15 15:28:48 --> Config Class Initialized
INFO - 2025-11-15 15:28:48 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:28:48 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:28:48 --> Utf8 Class Initialized
INFO - 2025-11-15 15:28:48 --> URI Class Initialized
INFO - 2025-11-15 15:28:48 --> Router Class Initialized
INFO - 2025-11-15 15:28:48 --> Output Class Initialized
INFO - 2025-11-15 15:28:48 --> Security Class Initialized
DEBUG - 2025-11-15 15:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:28:48 --> Input Class Initialized
INFO - 2025-11-15 15:28:48 --> Language Class Initialized
ERROR - 2025-11-15 15:28:48 --> 404 Page Not Found: /index
INFO - 2025-11-15 15:28:53 --> Config Class Initialized
INFO - 2025-11-15 15:28:53 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:28:53 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:28:53 --> Utf8 Class Initialized
INFO - 2025-11-15 15:28:53 --> URI Class Initialized
DEBUG - 2025-11-15 15:28:53 --> No URI present. Default controller set.
INFO - 2025-11-15 15:28:53 --> Router Class Initialized
INFO - 2025-11-15 15:28:53 --> Output Class Initialized
INFO - 2025-11-15 15:28:53 --> Security Class Initialized
DEBUG - 2025-11-15 15:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:28:53 --> Input Class Initialized
INFO - 2025-11-15 15:28:53 --> Language Class Initialized
INFO - 2025-11-15 15:28:53 --> Loader Class Initialized
INFO - 2025-11-15 15:28:53 --> Helper loaded: url_helper
INFO - 2025-11-15 15:28:53 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:28:53 --> Helper loaded: form_helper
INFO - 2025-11-15 15:28:53 --> Form Validation Class Initialized
INFO - 2025-11-15 15:28:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:28:53 --> Pagination Class Initialized
INFO - 2025-11-15 15:28:53 --> Model "Common" initialized
INFO - 2025-11-15 15:28:53 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:28:53 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:28:53 --> Controller Class Initialized
INFO - 2025-11-15 15:28:53 --> Model "Login_model" initialized
INFO - 2025-11-15 15:28:53 --> Model "SettingsModel" initialized
DEBUG - 2025-11-15 15:28:53 --> Session class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:28:53 --> File loaded: C:\xampp\htdocs\demo_system\application\views\home_page.php
INFO - 2025-11-15 15:28:53 --> Final output sent to browser
DEBUG - 2025-11-15 15:28:53 --> Total execution time: 0.0651
INFO - 2025-11-15 15:28:56 --> Config Class Initialized
INFO - 2025-11-15 15:28:56 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:28:56 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:28:56 --> Utf8 Class Initialized
INFO - 2025-11-15 15:28:56 --> URI Class Initialized
DEBUG - 2025-11-15 15:28:56 --> No URI present. Default controller set.
INFO - 2025-11-15 15:28:56 --> Router Class Initialized
INFO - 2025-11-15 15:28:56 --> Output Class Initialized
INFO - 2025-11-15 15:28:56 --> Security Class Initialized
DEBUG - 2025-11-15 15:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:28:56 --> Input Class Initialized
INFO - 2025-11-15 15:28:56 --> Language Class Initialized
INFO - 2025-11-15 15:28:56 --> Loader Class Initialized
INFO - 2025-11-15 15:28:56 --> Helper loaded: url_helper
INFO - 2025-11-15 15:28:56 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:28:56 --> Helper loaded: form_helper
INFO - 2025-11-15 15:28:56 --> Form Validation Class Initialized
INFO - 2025-11-15 15:28:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:28:56 --> Pagination Class Initialized
INFO - 2025-11-15 15:28:56 --> Model "Common" initialized
INFO - 2025-11-15 15:28:56 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:28:56 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:28:56 --> Controller Class Initialized
INFO - 2025-11-15 15:28:56 --> Model "Login_model" initialized
INFO - 2025-11-15 15:28:56 --> Model "SettingsModel" initialized
DEBUG - 2025-11-15 15:28:56 --> Session class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:28:56 --> File loaded: C:\xampp\htdocs\demo_system\application\views\home_page.php
INFO - 2025-11-15 15:28:56 --> Final output sent to browser
DEBUG - 2025-11-15 15:28:56 --> Total execution time: 0.0465
INFO - 2025-11-15 15:28:57 --> Config Class Initialized
INFO - 2025-11-15 15:28:57 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:28:57 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:28:57 --> Utf8 Class Initialized
INFO - 2025-11-15 15:28:57 --> URI Class Initialized
DEBUG - 2025-11-15 15:28:57 --> No URI present. Default controller set.
INFO - 2025-11-15 15:28:57 --> Router Class Initialized
INFO - 2025-11-15 15:28:57 --> Output Class Initialized
INFO - 2025-11-15 15:28:57 --> Security Class Initialized
DEBUG - 2025-11-15 15:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:28:57 --> Input Class Initialized
INFO - 2025-11-15 15:28:57 --> Language Class Initialized
INFO - 2025-11-15 15:28:57 --> Loader Class Initialized
INFO - 2025-11-15 15:28:57 --> Helper loaded: url_helper
INFO - 2025-11-15 15:28:57 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:28:57 --> Helper loaded: form_helper
INFO - 2025-11-15 15:28:57 --> Form Validation Class Initialized
INFO - 2025-11-15 15:28:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:28:57 --> Pagination Class Initialized
INFO - 2025-11-15 15:28:57 --> Model "Common" initialized
INFO - 2025-11-15 15:28:57 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:28:57 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:28:57 --> Controller Class Initialized
INFO - 2025-11-15 15:28:57 --> Model "Login_model" initialized
INFO - 2025-11-15 15:28:57 --> Model "SettingsModel" initialized
DEBUG - 2025-11-15 15:28:57 --> Session class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:28:57 --> File loaded: C:\xampp\htdocs\demo_system\application\views\home_page.php
INFO - 2025-11-15 15:28:57 --> Final output sent to browser
DEBUG - 2025-11-15 15:28:57 --> Total execution time: 0.0465
INFO - 2025-11-15 15:30:09 --> Config Class Initialized
INFO - 2025-11-15 15:30:09 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:30:09 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:30:09 --> Utf8 Class Initialized
INFO - 2025-11-15 15:30:09 --> URI Class Initialized
DEBUG - 2025-11-15 15:30:09 --> No URI present. Default controller set.
INFO - 2025-11-15 15:30:09 --> Router Class Initialized
INFO - 2025-11-15 15:30:09 --> Output Class Initialized
INFO - 2025-11-15 15:30:09 --> Security Class Initialized
DEBUG - 2025-11-15 15:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:30:09 --> Input Class Initialized
INFO - 2025-11-15 15:30:09 --> Language Class Initialized
INFO - 2025-11-15 15:30:09 --> Loader Class Initialized
INFO - 2025-11-15 15:30:09 --> Helper loaded: url_helper
INFO - 2025-11-15 15:30:09 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:30:09 --> Helper loaded: form_helper
INFO - 2025-11-15 15:30:09 --> Form Validation Class Initialized
INFO - 2025-11-15 15:30:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:30:09 --> Pagination Class Initialized
INFO - 2025-11-15 15:30:09 --> Model "Common" initialized
INFO - 2025-11-15 15:30:09 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:30:09 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:30:09 --> Controller Class Initialized
INFO - 2025-11-15 15:30:09 --> Model "Login_model" initialized
INFO - 2025-11-15 15:30:09 --> Model "SettingsModel" initialized
DEBUG - 2025-11-15 15:30:09 --> Session class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:30:09 --> File loaded: C:\xampp\htdocs\demo_system\application\views\home_page.php
INFO - 2025-11-15 15:30:09 --> Final output sent to browser
DEBUG - 2025-11-15 15:30:09 --> Total execution time: 0.0545
INFO - 2025-11-15 15:30:35 --> Config Class Initialized
INFO - 2025-11-15 15:30:35 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:30:35 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:30:35 --> Utf8 Class Initialized
INFO - 2025-11-15 15:30:35 --> URI Class Initialized
DEBUG - 2025-11-15 15:30:35 --> No URI present. Default controller set.
INFO - 2025-11-15 15:30:35 --> Router Class Initialized
INFO - 2025-11-15 15:30:35 --> Output Class Initialized
INFO - 2025-11-15 15:30:35 --> Security Class Initialized
DEBUG - 2025-11-15 15:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:30:35 --> Input Class Initialized
INFO - 2025-11-15 15:30:35 --> Language Class Initialized
INFO - 2025-11-15 15:30:35 --> Loader Class Initialized
INFO - 2025-11-15 15:30:35 --> Helper loaded: url_helper
INFO - 2025-11-15 15:30:35 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:30:35 --> Helper loaded: form_helper
INFO - 2025-11-15 15:30:35 --> Form Validation Class Initialized
INFO - 2025-11-15 15:30:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:30:35 --> Pagination Class Initialized
INFO - 2025-11-15 15:30:35 --> Model "Common" initialized
INFO - 2025-11-15 15:30:35 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:30:35 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:30:35 --> Controller Class Initialized
INFO - 2025-11-15 15:30:35 --> Model "Login_model" initialized
INFO - 2025-11-15 15:30:35 --> Model "SettingsModel" initialized
DEBUG - 2025-11-15 15:30:35 --> Session class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:30:35 --> File loaded: C:\xampp\htdocs\demo_system\application\views\home_page.php
INFO - 2025-11-15 15:30:35 --> Final output sent to browser
DEBUG - 2025-11-15 15:30:35 --> Total execution time: 0.0832
INFO - 2025-11-15 15:31:18 --> Config Class Initialized
INFO - 2025-11-15 15:31:18 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:31:18 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:31:18 --> Utf8 Class Initialized
INFO - 2025-11-15 15:31:18 --> URI Class Initialized
DEBUG - 2025-11-15 15:31:18 --> No URI present. Default controller set.
INFO - 2025-11-15 15:31:18 --> Router Class Initialized
INFO - 2025-11-15 15:31:18 --> Output Class Initialized
INFO - 2025-11-15 15:31:18 --> Security Class Initialized
DEBUG - 2025-11-15 15:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:31:18 --> Input Class Initialized
INFO - 2025-11-15 15:31:18 --> Language Class Initialized
INFO - 2025-11-15 15:31:18 --> Loader Class Initialized
INFO - 2025-11-15 15:31:18 --> Helper loaded: url_helper
INFO - 2025-11-15 15:31:18 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:31:18 --> Helper loaded: form_helper
INFO - 2025-11-15 15:31:18 --> Form Validation Class Initialized
INFO - 2025-11-15 15:31:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:31:18 --> Pagination Class Initialized
INFO - 2025-11-15 15:31:18 --> Model "Common" initialized
INFO - 2025-11-15 15:31:18 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:31:18 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:31:18 --> Controller Class Initialized
INFO - 2025-11-15 15:31:18 --> Model "Login_model" initialized
INFO - 2025-11-15 15:31:18 --> Model "SettingsModel" initialized
DEBUG - 2025-11-15 15:31:18 --> Session class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:31:18 --> File loaded: C:\xampp\htdocs\demo_system\application\views\home_page.php
INFO - 2025-11-15 15:31:18 --> Final output sent to browser
DEBUG - 2025-11-15 15:31:18 --> Total execution time: 0.0481
INFO - 2025-11-15 15:32:50 --> Config Class Initialized
INFO - 2025-11-15 15:32:50 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:32:50 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:32:50 --> Utf8 Class Initialized
INFO - 2025-11-15 15:32:50 --> URI Class Initialized
INFO - 2025-11-15 15:32:50 --> Router Class Initialized
INFO - 2025-11-15 15:32:50 --> Output Class Initialized
INFO - 2025-11-15 15:32:50 --> Security Class Initialized
DEBUG - 2025-11-15 15:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:32:50 --> Input Class Initialized
INFO - 2025-11-15 15:32:50 --> Language Class Initialized
INFO - 2025-11-15 15:32:50 --> Loader Class Initialized
INFO - 2025-11-15 15:32:50 --> Helper loaded: url_helper
INFO - 2025-11-15 15:32:50 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:32:50 --> Helper loaded: form_helper
INFO - 2025-11-15 15:32:50 --> Form Validation Class Initialized
INFO - 2025-11-15 15:32:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:32:50 --> Pagination Class Initialized
INFO - 2025-11-15 15:32:50 --> Model "Common" initialized
INFO - 2025-11-15 15:32:50 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:32:50 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:32:50 --> Controller Class Initialized
INFO - 2025-11-15 15:32:50 --> Model "Login_model" initialized
INFO - 2025-11-15 15:32:50 --> Model "SettingsModel" initialized
DEBUG - 2025-11-15 15:32:50 --> Session class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:32:50 --> Config Class Initialized
INFO - 2025-11-15 15:32:50 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:32:50 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:32:50 --> Utf8 Class Initialized
INFO - 2025-11-15 15:32:50 --> URI Class Initialized
INFO - 2025-11-15 15:32:50 --> Router Class Initialized
INFO - 2025-11-15 15:32:50 --> Output Class Initialized
INFO - 2025-11-15 15:32:50 --> Security Class Initialized
DEBUG - 2025-11-15 15:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:32:50 --> Input Class Initialized
INFO - 2025-11-15 15:32:50 --> Language Class Initialized
INFO - 2025-11-15 15:32:50 --> Loader Class Initialized
INFO - 2025-11-15 15:32:50 --> Helper loaded: url_helper
INFO - 2025-11-15 15:32:50 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:32:50 --> Helper loaded: form_helper
INFO - 2025-11-15 15:32:50 --> Form Validation Class Initialized
INFO - 2025-11-15 15:32:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:32:50 --> Pagination Class Initialized
INFO - 2025-11-15 15:32:50 --> Model "Common" initialized
INFO - 2025-11-15 15:32:50 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:32:50 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:32:50 --> Controller Class Initialized
DEBUG - 2025-11-15 15:32:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:32:50 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:32:50 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:32:50 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:32:50 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:32:50 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:32:50 --> Model "ToDoModel" initialized
INFO - 2025-11-15 15:32:50 --> Model "Login_model" initialized
INFO - 2025-11-15 15:32:50 --> Model "EmailBlast_model" initialized
INFO - 2025-11-15 15:32:50 --> User Agent Class Initialized
INFO - 2025-11-15 15:32:50 --> File loaded: C:\xampp\htdocs\demo_system\application\views\dashboard_admin.php
INFO - 2025-11-15 15:32:50 --> Final output sent to browser
DEBUG - 2025-11-15 15:32:50 --> Total execution time: 0.0906
INFO - 2025-11-15 15:32:50 --> Config Class Initialized
INFO - 2025-11-15 15:32:50 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:32:50 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:32:50 --> Utf8 Class Initialized
INFO - 2025-11-15 15:32:50 --> URI Class Initialized
INFO - 2025-11-15 15:32:50 --> Router Class Initialized
INFO - 2025-11-15 15:32:50 --> Output Class Initialized
INFO - 2025-11-15 15:32:50 --> Security Class Initialized
DEBUG - 2025-11-15 15:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:32:50 --> Input Class Initialized
INFO - 2025-11-15 15:32:50 --> Language Class Initialized
ERROR - 2025-11-15 15:32:50 --> 404 Page Not Found: Page/assets
INFO - 2025-11-15 15:38:53 --> Config Class Initialized
INFO - 2025-11-15 15:38:53 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:38:53 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:38:53 --> Utf8 Class Initialized
INFO - 2025-11-15 15:38:53 --> URI Class Initialized
INFO - 2025-11-15 15:38:53 --> Router Class Initialized
INFO - 2025-11-15 15:38:53 --> Output Class Initialized
INFO - 2025-11-15 15:38:53 --> Security Class Initialized
DEBUG - 2025-11-15 15:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:38:53 --> Input Class Initialized
INFO - 2025-11-15 15:38:53 --> Language Class Initialized
INFO - 2025-11-15 15:38:53 --> Loader Class Initialized
INFO - 2025-11-15 15:38:53 --> Helper loaded: url_helper
INFO - 2025-11-15 15:38:53 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:38:53 --> Helper loaded: form_helper
INFO - 2025-11-15 15:38:53 --> Form Validation Class Initialized
INFO - 2025-11-15 15:38:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:38:53 --> Pagination Class Initialized
INFO - 2025-11-15 15:38:53 --> Model "Common" initialized
INFO - 2025-11-15 15:38:53 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:38:53 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:38:53 --> Controller Class Initialized
DEBUG - 2025-11-15 15:38:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:38:53 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:38:53 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:38:53 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:38:53 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:38:53 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:38:53 --> Model "ToDoModel" initialized
INFO - 2025-11-15 15:38:53 --> Model "Login_model" initialized
INFO - 2025-11-15 15:38:53 --> Model "EmailBlast_model" initialized
INFO - 2025-11-15 15:38:53 --> User Agent Class Initialized
INFO - 2025-11-15 15:38:53 --> File loaded: C:\xampp\htdocs\demo_system\application\views\dashboard_admin.php
INFO - 2025-11-15 15:38:53 --> Final output sent to browser
DEBUG - 2025-11-15 15:38:53 --> Total execution time: 0.0874
INFO - 2025-11-15 15:38:53 --> Config Class Initialized
INFO - 2025-11-15 15:38:53 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:38:53 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:38:53 --> Utf8 Class Initialized
INFO - 2025-11-15 15:38:53 --> URI Class Initialized
INFO - 2025-11-15 15:38:53 --> Router Class Initialized
INFO - 2025-11-15 15:38:53 --> Output Class Initialized
INFO - 2025-11-15 15:38:53 --> Security Class Initialized
DEBUG - 2025-11-15 15:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:38:53 --> Input Class Initialized
INFO - 2025-11-15 15:38:53 --> Language Class Initialized
ERROR - 2025-11-15 15:38:53 --> 404 Page Not Found: Page/assets
INFO - 2025-11-15 15:38:57 --> Config Class Initialized
INFO - 2025-11-15 15:38:57 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:38:57 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:38:57 --> Utf8 Class Initialized
INFO - 2025-11-15 15:38:57 --> URI Class Initialized
INFO - 2025-11-15 15:38:57 --> Router Class Initialized
INFO - 2025-11-15 15:38:57 --> Output Class Initialized
INFO - 2025-11-15 15:38:57 --> Security Class Initialized
DEBUG - 2025-11-15 15:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:38:57 --> Input Class Initialized
INFO - 2025-11-15 15:38:57 --> Language Class Initialized
INFO - 2025-11-15 15:38:57 --> Loader Class Initialized
INFO - 2025-11-15 15:38:57 --> Helper loaded: url_helper
INFO - 2025-11-15 15:38:57 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:38:57 --> Helper loaded: form_helper
INFO - 2025-11-15 15:38:57 --> Form Validation Class Initialized
INFO - 2025-11-15 15:38:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:38:57 --> Pagination Class Initialized
INFO - 2025-11-15 15:38:57 --> Model "Common" initialized
INFO - 2025-11-15 15:38:57 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:38:57 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:38:57 --> Controller Class Initialized
DEBUG - 2025-11-15 15:38:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:38:57 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:38:57 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:38:57 --> Model "Login_model" initialized
INFO - 2025-11-15 15:38:57 --> User Agent Class Initialized
INFO - 2025-11-15 15:38:57 --> File loaded: C:\xampp\htdocs\demo_system\application\views\settings_school_info.php
INFO - 2025-11-15 15:38:57 --> Final output sent to browser
DEBUG - 2025-11-15 15:38:57 --> Total execution time: 0.0588
INFO - 2025-11-15 15:38:57 --> Config Class Initialized
INFO - 2025-11-15 15:38:57 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:38:57 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:38:57 --> Utf8 Class Initialized
INFO - 2025-11-15 15:38:57 --> URI Class Initialized
INFO - 2025-11-15 15:38:57 --> Router Class Initialized
INFO - 2025-11-15 15:38:57 --> Output Class Initialized
INFO - 2025-11-15 15:38:57 --> Security Class Initialized
DEBUG - 2025-11-15 15:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:38:57 --> Input Class Initialized
INFO - 2025-11-15 15:38:57 --> Language Class Initialized
ERROR - 2025-11-15 15:38:57 --> 404 Page Not Found: Settings/assets
INFO - 2025-11-15 15:39:05 --> Config Class Initialized
INFO - 2025-11-15 15:39:05 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:39:05 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:39:05 --> Utf8 Class Initialized
INFO - 2025-11-15 15:39:05 --> URI Class Initialized
INFO - 2025-11-15 15:39:05 --> Router Class Initialized
INFO - 2025-11-15 15:39:05 --> Output Class Initialized
INFO - 2025-11-15 15:39:05 --> Security Class Initialized
DEBUG - 2025-11-15 15:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:39:05 --> Input Class Initialized
INFO - 2025-11-15 15:39:05 --> Language Class Initialized
INFO - 2025-11-15 15:39:05 --> Loader Class Initialized
INFO - 2025-11-15 15:39:05 --> Helper loaded: url_helper
INFO - 2025-11-15 15:39:05 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:39:05 --> Helper loaded: form_helper
INFO - 2025-11-15 15:39:05 --> Form Validation Class Initialized
INFO - 2025-11-15 15:39:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:39:05 --> Pagination Class Initialized
INFO - 2025-11-15 15:39:05 --> Model "Common" initialized
INFO - 2025-11-15 15:39:05 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:39:05 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:39:05 --> Controller Class Initialized
DEBUG - 2025-11-15 15:39:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:39:05 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:39:05 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:39:05 --> Model "Login_model" initialized
INFO - 2025-11-15 15:39:05 --> User Agent Class Initialized
INFO - 2025-11-15 15:39:05 --> File loaded: C:\xampp\htdocs\demo_system\application\views\settings_school_info.php
INFO - 2025-11-15 15:39:05 --> Config Class Initialized
INFO - 2025-11-15 15:39:05 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:39:05 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:39:05 --> Utf8 Class Initialized
INFO - 2025-11-15 15:39:05 --> URI Class Initialized
INFO - 2025-11-15 15:39:05 --> Router Class Initialized
INFO - 2025-11-15 15:39:05 --> Output Class Initialized
INFO - 2025-11-15 15:39:05 --> Security Class Initialized
DEBUG - 2025-11-15 15:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:39:05 --> Input Class Initialized
INFO - 2025-11-15 15:39:05 --> Language Class Initialized
INFO - 2025-11-15 15:39:05 --> Loader Class Initialized
INFO - 2025-11-15 15:39:05 --> Helper loaded: url_helper
INFO - 2025-11-15 15:39:05 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:39:05 --> Helper loaded: form_helper
INFO - 2025-11-15 15:39:05 --> Form Validation Class Initialized
INFO - 2025-11-15 15:39:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:39:05 --> Pagination Class Initialized
INFO - 2025-11-15 15:39:05 --> Model "Common" initialized
INFO - 2025-11-15 15:39:05 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:39:05 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:39:05 --> Controller Class Initialized
DEBUG - 2025-11-15 15:39:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:39:05 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:39:05 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:39:05 --> Model "Login_model" initialized
INFO - 2025-11-15 15:39:05 --> User Agent Class Initialized
INFO - 2025-11-15 15:39:05 --> File loaded: C:\xampp\htdocs\demo_system\application\views\settings_school_info.php
INFO - 2025-11-15 15:39:05 --> Final output sent to browser
DEBUG - 2025-11-15 15:39:05 --> Total execution time: 0.0699
INFO - 2025-11-15 15:39:05 --> Config Class Initialized
INFO - 2025-11-15 15:39:05 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:39:05 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:39:05 --> Utf8 Class Initialized
INFO - 2025-11-15 15:39:05 --> URI Class Initialized
INFO - 2025-11-15 15:39:05 --> Router Class Initialized
INFO - 2025-11-15 15:39:05 --> Output Class Initialized
INFO - 2025-11-15 15:39:05 --> Security Class Initialized
DEBUG - 2025-11-15 15:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:39:05 --> Input Class Initialized
INFO - 2025-11-15 15:39:05 --> Language Class Initialized
ERROR - 2025-11-15 15:39:05 --> 404 Page Not Found: Settings/assets
INFO - 2025-11-15 15:39:10 --> Config Class Initialized
INFO - 2025-11-15 15:39:10 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:39:10 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:39:10 --> Utf8 Class Initialized
INFO - 2025-11-15 15:39:10 --> URI Class Initialized
INFO - 2025-11-15 15:39:10 --> Router Class Initialized
INFO - 2025-11-15 15:39:10 --> Output Class Initialized
INFO - 2025-11-15 15:39:10 --> Security Class Initialized
DEBUG - 2025-11-15 15:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:39:10 --> Input Class Initialized
INFO - 2025-11-15 15:39:10 --> Language Class Initialized
INFO - 2025-11-15 15:39:10 --> Loader Class Initialized
INFO - 2025-11-15 15:39:10 --> Helper loaded: url_helper
INFO - 2025-11-15 15:39:10 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:39:10 --> Helper loaded: form_helper
INFO - 2025-11-15 15:39:10 --> Form Validation Class Initialized
INFO - 2025-11-15 15:39:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:39:10 --> Pagination Class Initialized
INFO - 2025-11-15 15:39:10 --> Model "Common" initialized
INFO - 2025-11-15 15:39:10 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:39:10 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:39:10 --> Controller Class Initialized
DEBUG - 2025-11-15 15:39:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:39:10 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:39:10 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:39:10 --> Model "PersonnelModel" initialized
INFO - 2025-11-15 15:39:10 --> Model "InstructorModel" initialized
INFO - 2025-11-15 15:39:10 --> Model "LibraryModel" initialized
INFO - 2025-11-15 15:39:10 --> Model "Login_model" initialized
INFO - 2025-11-15 15:39:10 --> File loaded: C:\xampp\htdocs\demo_system\application\views\student_report.php
INFO - 2025-11-15 15:39:10 --> Final output sent to browser
DEBUG - 2025-11-15 15:39:10 --> Total execution time: 0.0596
INFO - 2025-11-15 15:39:10 --> Config Class Initialized
INFO - 2025-11-15 15:39:10 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:39:10 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:39:10 --> Utf8 Class Initialized
INFO - 2025-11-15 15:39:10 --> URI Class Initialized
INFO - 2025-11-15 15:39:10 --> Router Class Initialized
INFO - 2025-11-15 15:39:10 --> Output Class Initialized
INFO - 2025-11-15 15:39:10 --> Security Class Initialized
DEBUG - 2025-11-15 15:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:39:10 --> Input Class Initialized
INFO - 2025-11-15 15:39:10 --> Language Class Initialized
ERROR - 2025-11-15 15:39:10 --> 404 Page Not Found: Ren/assets
INFO - 2025-11-15 15:39:13 --> Config Class Initialized
INFO - 2025-11-15 15:39:13 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:39:13 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:39:13 --> Utf8 Class Initialized
INFO - 2025-11-15 15:39:13 --> URI Class Initialized
INFO - 2025-11-15 15:39:13 --> Router Class Initialized
INFO - 2025-11-15 15:39:13 --> Output Class Initialized
INFO - 2025-11-15 15:39:13 --> Security Class Initialized
DEBUG - 2025-11-15 15:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:39:13 --> Input Class Initialized
INFO - 2025-11-15 15:39:13 --> Language Class Initialized
INFO - 2025-11-15 15:39:13 --> Loader Class Initialized
INFO - 2025-11-15 15:39:13 --> Helper loaded: url_helper
INFO - 2025-11-15 15:39:13 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:39:13 --> Helper loaded: form_helper
INFO - 2025-11-15 15:39:13 --> Form Validation Class Initialized
INFO - 2025-11-15 15:39:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:39:13 --> Pagination Class Initialized
INFO - 2025-11-15 15:39:13 --> Model "Common" initialized
INFO - 2025-11-15 15:39:13 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:39:13 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:39:13 --> Controller Class Initialized
DEBUG - 2025-11-15 15:39:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:39:13 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:39:13 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:39:13 --> Model "Login_model" initialized
INFO - 2025-11-15 15:39:13 --> User Agent Class Initialized
INFO - 2025-11-15 15:39:13 --> File loaded: C:\xampp\htdocs\demo_system\application\views\settings_school_info.php
INFO - 2025-11-15 15:39:13 --> Final output sent to browser
DEBUG - 2025-11-15 15:39:13 --> Total execution time: 0.0547
INFO - 2025-11-15 15:39:13 --> Config Class Initialized
INFO - 2025-11-15 15:39:13 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:39:13 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:39:13 --> Utf8 Class Initialized
INFO - 2025-11-15 15:39:13 --> URI Class Initialized
INFO - 2025-11-15 15:39:13 --> Router Class Initialized
INFO - 2025-11-15 15:39:13 --> Output Class Initialized
INFO - 2025-11-15 15:39:13 --> Security Class Initialized
DEBUG - 2025-11-15 15:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:39:13 --> Input Class Initialized
INFO - 2025-11-15 15:39:13 --> Language Class Initialized
ERROR - 2025-11-15 15:39:13 --> 404 Page Not Found: Settings/assets
INFO - 2025-11-15 15:39:20 --> Config Class Initialized
INFO - 2025-11-15 15:39:20 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:39:20 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:39:20 --> Utf8 Class Initialized
INFO - 2025-11-15 15:39:20 --> URI Class Initialized
INFO - 2025-11-15 15:39:20 --> Router Class Initialized
INFO - 2025-11-15 15:39:20 --> Output Class Initialized
INFO - 2025-11-15 15:39:20 --> Security Class Initialized
DEBUG - 2025-11-15 15:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:39:20 --> Input Class Initialized
INFO - 2025-11-15 15:39:20 --> Language Class Initialized
INFO - 2025-11-15 15:39:20 --> Loader Class Initialized
INFO - 2025-11-15 15:39:20 --> Helper loaded: url_helper
INFO - 2025-11-15 15:39:20 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:39:20 --> Helper loaded: form_helper
INFO - 2025-11-15 15:39:20 --> Form Validation Class Initialized
INFO - 2025-11-15 15:39:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:39:20 --> Pagination Class Initialized
INFO - 2025-11-15 15:39:20 --> Model "Common" initialized
INFO - 2025-11-15 15:39:20 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:39:20 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:39:20 --> Controller Class Initialized
DEBUG - 2025-11-15 15:39:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:39:20 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:39:20 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:39:20 --> Model "Login_model" initialized
INFO - 2025-11-15 15:39:20 --> User Agent Class Initialized
INFO - 2025-11-15 15:39:20 --> File loaded: C:\xampp\htdocs\demo_system\application\views\settings_school_info.php
INFO - 2025-11-15 15:39:20 --> Config Class Initialized
INFO - 2025-11-15 15:39:20 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:39:20 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:39:20 --> Utf8 Class Initialized
INFO - 2025-11-15 15:39:20 --> URI Class Initialized
INFO - 2025-11-15 15:39:20 --> Router Class Initialized
INFO - 2025-11-15 15:39:20 --> Output Class Initialized
INFO - 2025-11-15 15:39:20 --> Security Class Initialized
DEBUG - 2025-11-15 15:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:39:20 --> Input Class Initialized
INFO - 2025-11-15 15:39:20 --> Language Class Initialized
INFO - 2025-11-15 15:39:20 --> Loader Class Initialized
INFO - 2025-11-15 15:39:20 --> Helper loaded: url_helper
INFO - 2025-11-15 15:39:20 --> Database Driver Class Initialized
DEBUG - 2025-11-15 15:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-15 15:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-15 15:39:20 --> Helper loaded: form_helper
INFO - 2025-11-15 15:39:20 --> Form Validation Class Initialized
INFO - 2025-11-15 15:39:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-15 15:39:20 --> Pagination Class Initialized
INFO - 2025-11-15 15:39:20 --> Model "Common" initialized
INFO - 2025-11-15 15:39:20 --> Model "Ren_model" initialized
INFO - 2025-11-15 15:39:20 --> Model "SGODModel" initialized
INFO - 2025-11-15 15:39:20 --> Controller Class Initialized
DEBUG - 2025-11-15 15:39:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-11-15 15:39:20 --> Model "StudentModel" initialized
INFO - 2025-11-15 15:39:20 --> Model "SettingsModel" initialized
INFO - 2025-11-15 15:39:20 --> Model "Login_model" initialized
INFO - 2025-11-15 15:39:20 --> User Agent Class Initialized
INFO - 2025-11-15 15:39:20 --> File loaded: C:\xampp\htdocs\demo_system\application\views\settings_school_info.php
INFO - 2025-11-15 15:39:20 --> Final output sent to browser
DEBUG - 2025-11-15 15:39:20 --> Total execution time: 0.0740
INFO - 2025-11-15 15:39:20 --> Config Class Initialized
INFO - 2025-11-15 15:39:20 --> Hooks Class Initialized
DEBUG - 2025-11-15 15:39:20 --> UTF-8 Support Enabled
INFO - 2025-11-15 15:39:20 --> Utf8 Class Initialized
INFO - 2025-11-15 15:39:20 --> URI Class Initialized
INFO - 2025-11-15 15:39:20 --> Router Class Initialized
INFO - 2025-11-15 15:39:20 --> Output Class Initialized
INFO - 2025-11-15 15:39:20 --> Security Class Initialized
DEBUG - 2025-11-15 15:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-15 15:39:20 --> Input Class Initialized
INFO - 2025-11-15 15:39:20 --> Language Class Initialized
ERROR - 2025-11-15 15:39:20 --> 404 Page Not Found: Settings/assets
