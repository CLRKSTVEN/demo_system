<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-11-16 07:55:55 --> Config Class Initialized
INFO - 2025-11-16 07:55:55 --> Hooks Class Initialized
DEBUG - 2025-11-16 07:55:55 --> UTF-8 Support Enabled
INFO - 2025-11-16 07:55:55 --> Utf8 Class Initialized
INFO - 2025-11-16 07:55:55 --> URI Class Initialized
DEBUG - 2025-11-16 07:55:55 --> No URI present. Default controller set.
INFO - 2025-11-16 07:55:55 --> Router Class Initialized
INFO - 2025-11-16 07:55:55 --> Output Class Initialized
INFO - 2025-11-16 07:55:55 --> Security Class Initialized
DEBUG - 2025-11-16 07:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-16 07:55:55 --> Input Class Initialized
INFO - 2025-11-16 07:55:55 --> Language Class Initialized
INFO - 2025-11-16 07:55:55 --> Loader Class Initialized
INFO - 2025-11-16 07:55:55 --> Helper loaded: url_helper
INFO - 2025-11-16 07:55:55 --> Database Driver Class Initialized
DEBUG - 2025-11-16 07:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 07:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 07:55:55 --> Helper loaded: form_helper
INFO - 2025-11-16 07:55:55 --> Form Validation Class Initialized
INFO - 2025-11-16 07:55:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-16 07:55:55 --> Pagination Class Initialized
INFO - 2025-11-16 07:55:55 --> Model "Common" initialized
INFO - 2025-11-16 07:55:55 --> Model "Ren_model" initialized
INFO - 2025-11-16 07:55:55 --> Model "SGODModel" initialized
INFO - 2025-11-16 07:55:55 --> Controller Class Initialized
INFO - 2025-11-16 07:55:55 --> Model "Login_model" initialized
INFO - 2025-11-16 07:55:55 --> Model "SettingsModel" initialized
DEBUG - 2025-11-16 07:55:55 --> Session class already loaded. Second attempt ignored.
INFO - 2025-11-16 07:55:55 --> File loaded: C:\xampp\htdocs\demo_system\application\views\home_page.php
INFO - 2025-11-16 07:55:55 --> Final output sent to browser
DEBUG - 2025-11-16 07:55:55 --> Total execution time: 0.1253
INFO - 2025-11-16 07:57:03 --> Config Class Initialized
INFO - 2025-11-16 07:57:03 --> Hooks Class Initialized
DEBUG - 2025-11-16 07:57:03 --> UTF-8 Support Enabled
INFO - 2025-11-16 07:57:03 --> Utf8 Class Initialized
INFO - 2025-11-16 07:57:03 --> URI Class Initialized
DEBUG - 2025-11-16 07:57:03 --> No URI present. Default controller set.
INFO - 2025-11-16 07:57:03 --> Router Class Initialized
INFO - 2025-11-16 07:57:03 --> Output Class Initialized
INFO - 2025-11-16 07:57:03 --> Security Class Initialized
DEBUG - 2025-11-16 07:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-16 07:57:03 --> Input Class Initialized
INFO - 2025-11-16 07:57:03 --> Language Class Initialized
INFO - 2025-11-16 07:57:03 --> Loader Class Initialized
INFO - 2025-11-16 07:57:03 --> Helper loaded: url_helper
INFO - 2025-11-16 07:57:03 --> Database Driver Class Initialized
DEBUG - 2025-11-16 07:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 07:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 07:57:03 --> Helper loaded: form_helper
INFO - 2025-11-16 07:57:03 --> Form Validation Class Initialized
INFO - 2025-11-16 07:57:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-16 07:57:03 --> Pagination Class Initialized
INFO - 2025-11-16 07:57:03 --> Model "Common" initialized
INFO - 2025-11-16 07:57:03 --> Model "Ren_model" initialized
INFO - 2025-11-16 07:57:03 --> Model "SGODModel" initialized
INFO - 2025-11-16 07:57:03 --> Controller Class Initialized
INFO - 2025-11-16 07:57:03 --> Model "Login_model" initialized
INFO - 2025-11-16 07:57:03 --> Model "SettingsModel" initialized
DEBUG - 2025-11-16 07:57:03 --> Session class already loaded. Second attempt ignored.
INFO - 2025-11-16 07:57:03 --> File loaded: C:\xampp\htdocs\demo_system\application\views\home_page.php
INFO - 2025-11-16 07:57:03 --> Final output sent to browser
DEBUG - 2025-11-16 07:57:03 --> Total execution time: 0.1036
INFO - 2025-11-16 07:57:16 --> Config Class Initialized
INFO - 2025-11-16 07:57:16 --> Hooks Class Initialized
DEBUG - 2025-11-16 07:57:16 --> UTF-8 Support Enabled
INFO - 2025-11-16 07:57:16 --> Utf8 Class Initialized
INFO - 2025-11-16 07:57:16 --> URI Class Initialized
DEBUG - 2025-11-16 07:57:16 --> No URI present. Default controller set.
INFO - 2025-11-16 07:57:16 --> Router Class Initialized
INFO - 2025-11-16 07:57:16 --> Output Class Initialized
INFO - 2025-11-16 07:57:16 --> Security Class Initialized
DEBUG - 2025-11-16 07:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-16 07:57:16 --> Input Class Initialized
INFO - 2025-11-16 07:57:16 --> Language Class Initialized
INFO - 2025-11-16 07:57:16 --> Loader Class Initialized
INFO - 2025-11-16 07:57:16 --> Helper loaded: url_helper
INFO - 2025-11-16 07:57:16 --> Database Driver Class Initialized
DEBUG - 2025-11-16 07:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 07:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 07:57:16 --> Helper loaded: form_helper
INFO - 2025-11-16 07:57:16 --> Form Validation Class Initialized
INFO - 2025-11-16 07:57:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-16 07:57:16 --> Pagination Class Initialized
INFO - 2025-11-16 07:57:16 --> Model "Common" initialized
INFO - 2025-11-16 07:57:16 --> Model "Ren_model" initialized
INFO - 2025-11-16 07:57:16 --> Model "SGODModel" initialized
INFO - 2025-11-16 07:57:16 --> Controller Class Initialized
INFO - 2025-11-16 07:57:16 --> Model "Login_model" initialized
INFO - 2025-11-16 07:57:16 --> Model "SettingsModel" initialized
DEBUG - 2025-11-16 07:57:16 --> Session class already loaded. Second attempt ignored.
INFO - 2025-11-16 07:57:16 --> File loaded: C:\xampp\htdocs\demo_system\application\views\home_page.php
INFO - 2025-11-16 07:57:16 --> Final output sent to browser
DEBUG - 2025-11-16 07:57:16 --> Total execution time: 0.1208
INFO - 2025-11-16 07:57:18 --> Config Class Initialized
INFO - 2025-11-16 07:57:18 --> Hooks Class Initialized
DEBUG - 2025-11-16 07:57:18 --> UTF-8 Support Enabled
INFO - 2025-11-16 07:57:18 --> Utf8 Class Initialized
INFO - 2025-11-16 07:57:18 --> URI Class Initialized
DEBUG - 2025-11-16 07:57:18 --> No URI present. Default controller set.
INFO - 2025-11-16 07:57:18 --> Router Class Initialized
INFO - 2025-11-16 07:57:18 --> Output Class Initialized
INFO - 2025-11-16 07:57:18 --> Security Class Initialized
DEBUG - 2025-11-16 07:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-11-16 07:57:18 --> Input Class Initialized
INFO - 2025-11-16 07:57:18 --> Language Class Initialized
INFO - 2025-11-16 07:57:18 --> Loader Class Initialized
INFO - 2025-11-16 07:57:18 --> Helper loaded: url_helper
INFO - 2025-11-16 07:57:18 --> Database Driver Class Initialized
DEBUG - 2025-11-16 07:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-11-16 07:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-11-16 07:57:18 --> Helper loaded: form_helper
INFO - 2025-11-16 07:57:18 --> Form Validation Class Initialized
INFO - 2025-11-16 07:57:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2025-11-16 07:57:18 --> Pagination Class Initialized
INFO - 2025-11-16 07:57:18 --> Model "Common" initialized
INFO - 2025-11-16 07:57:18 --> Model "Ren_model" initialized
INFO - 2025-11-16 07:57:18 --> Model "SGODModel" initialized
INFO - 2025-11-16 07:57:18 --> Controller Class Initialized
INFO - 2025-11-16 07:57:18 --> Model "Login_model" initialized
INFO - 2025-11-16 07:57:18 --> Model "SettingsModel" initialized
DEBUG - 2025-11-16 07:57:18 --> Session class already loaded. Second attempt ignored.
INFO - 2025-11-16 07:57:18 --> File loaded: C:\xampp\htdocs\demo_system\application\views\home_page.php
INFO - 2025-11-16 07:57:18 --> Final output sent to browser
DEBUG - 2025-11-16 07:57:18 --> Total execution time: 0.0965
